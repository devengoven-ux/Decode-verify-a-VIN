/* @ds-bundle: {"format":3,"namespace":"AutoTraderDesignSystem_295a36","components":[],"sourceHashes":{"deck-stage.js":"eac2199dccb4","ui_kits/web/App.jsx":"d67be074a4cc","ui_kits/web/Cards.jsx":"054429fb0ff9","ui_kits/web/Finance.jsx":"36230044c6c8","ui_kits/web/Header.jsx":"3b8cfc593c04","ui_kits/web/Home.jsx":"944a1d3f8532","ui_kits/web/Primitives.jsx":"16af68635f41","ui_kits/web/Results.jsx":"1ca207937ed6","ui_kits/web/VDP.jsx":"b4c4334a1d17","ui_kits/web/data.js":"2bb413741135"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.AutoTraderDesignSystem_295a36 = window.AutoTraderDesignSystem_295a36 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// deck-stage.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
/* BEGIN USAGE */
/**
 * <deck-stage> — reusable web component for HTML decks.
 *
 * Handles:
 *  (a) speaker notes — reads <script type="application/json" id="speaker-notes">
 *      and posts {slideIndexChanged: N} to the parent window on nav.
 *  (b) keyboard navigation — ←/→, PgUp/PgDn, Space, Home/End, number keys.
 *      On touch devices, tapping the left/right half of the stage goes
 *      prev/next — taps on links, buttons and other interactive slide
 *      content are left alone.
 *  (c) press R to reset to slide 0 (with a tasteful keyboard hint).
 *  (d) bottom-center overlay showing slide count + hints, fades out on idle.
 *  (e) auto-scaling — inner canvas is a fixed design size (default 1920×1080)
 *      scaled with `transform: scale()` to fit the viewport, letterboxed.
 *      Set the `noscale` attribute to render at authored size (1:1) — the
 *      PPTX exporter sets this so its DOM capture sees unscaled geometry.
 *  (f) print — `@media print` lays every slide out as its own page at the
 *      design size, so the browser's Print → Save as PDF produces a clean
 *      one-page-per-slide PDF with no extra setup.
 *  (g) thumbnail rail — resizable left-hand column of per-slide thumbnails
 *      (static clones). Click to navigate; ↑/↓ with a thumbnail focused to
 *      step between slides; drag to reorder; right-click for
 *      Skip / Move up / Move down / Delete (opens a Cancel/Delete confirm
 *      dialog). Drag the rail's right edge to resize; width persists to
 *      localStorage. Skipped slides carry `data-deck-skip`, are dimmed in
 *      the rail, omitted from prev/next navigation, and hidden at print.
 *      The rail is suppressed in presenting mode, in the host's Preview
 *      mode (ViewerMode='none'), on `noscale`, on narrow viewports
 *      (≤640px), and via the `no-rail` attribute. Rail mutations dispatch
 *      a `deckchange`
 *      CustomEvent on the element: detail = {action, from, to, slide}.
 *
 * Slides are HIDDEN, not unmounted. Non-active slides stay in the DOM with
 * `visibility: hidden` + `opacity: 0`, so their state (videos, iframes,
 * form inputs, React trees) is preserved across navigation.
 *
 * Lifecycle event — the component dispatches a `slidechange` CustomEvent on
 * itself whenever the active slide changes (including the initial mount).
 * The event bubbles and composes out of shadow DOM, so you can listen on
 * the <deck-stage> element or on document:
 *
 *   document.querySelector('deck-stage').addEventListener('slidechange', (e) => {
 *     e.detail.index         // new 0-based index
 *     e.detail.previousIndex // previous index, or -1 on init
 *     e.detail.total         // total slide count
 *     e.detail.slide         // the new active slide element
 *     e.detail.previousSlide // the prior slide element, or null on init
 *     e.detail.reason        // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
 *   });
 *
 * Persistence: none at the deck level. The host app keeps the current slide
 * in its own URL (?slide=) and re-delivers it via location.hash on load, so a
 * bare load with no hash always starts at slide 1.
 *
 * Usage:
 *   <style>deck-stage:not(:defined){visibility:hidden}</style>
 *   <deck-stage width="1920" height="1080">
 *     <section data-label="Title">...</section>
 *     <section data-label="Agenda">...</section>
 *   </deck-stage>
 *   <script src="deck-stage.js"></script>
 *
 * The :not(:defined) rule prevents a flash of the first slide at its
 * authored styles before this script runs and attaches the shadow root.
 *
 * Slides are the direct element children of <deck-stage>. Each slide is
 * automatically tagged with:
 *   - data-screen-label="NN Label"   (1-indexed, for comment flow)
 *   - data-om-validate="no_overflowing_text,no_overlapping_text,slide_sized_text"
 *
 * Speaker notes stay in sync because the component posts {slideIndexChanged: N}
 * to the parent — just include the #speaker-notes script tag if asked for notes.
 *
 * Authoring guidance:
 *   - Write slide bodies as static HTML inside <deck-stage>, with sizing via
 *     CSS custom properties in a <style> block rather than JS constants.
 *     Static slide markup is what lets the user click a heading in edit mode
 *     and retype it directly; a slide rendered through <script type="text/babel">,
 *     React, or a loop over a JS array has to round-trip every tweak through a
 *     chat message instead. Reach for script-generated slides only when the
 *     content genuinely needs interactive behaviour static HTML can't express.
 *   - Do NOT set position/inset/width/height on the slide <section> elements —
 *     the component absolutely positions every slotted child for you.
 *   - Entrance animations: make the visible end-state the base style and
 *     animate *from* hidden, so print and reduced-motion show content.
 *     Gate the animation on [data-deck-active] and the motion query, e.g.
 *     `@media (prefers-reduced-motion:no-preference){ [data-deck-active] .x{animation:fade-in .5s both} }`.
 *     Avoid infinite decorative loops on slide content.
 */
/* END USAGE */

(() => {
  const DESIGN_W_DEFAULT = 1920;
  const DESIGN_H_DEFAULT = 1080;
  const OVERLAY_HIDE_MS = 1800;
  const VALIDATE_ATTR = 'no_overflowing_text,no_overlapping_text,slide_sized_text';
  const FINE_POINTER_MQ = matchMedia('(hover: hover) and (pointer: fine)');
  const NARROW_MQ = matchMedia('(max-width: 640px)');
  // Slide-authored controls that should keep a tap instead of it navigating.
  const INTERACTIVE_SEL = 'a[href], button, input, select, textarea, summary, label, video[controls], audio[controls], [role="button"], [onclick], [tabindex]:not([tabindex^="-"]), [contenteditable]:not([contenteditable="false" i])';
  const pad2 = n => String(n).padStart(2, '0');

  // Label precedence: data-label → data-screen-label (number stripped) → first heading → "Slide".
  const getSlideLabel = el => {
    const explicit = el.getAttribute('data-label');
    if (explicit) return explicit;
    const existing = el.getAttribute('data-screen-label');
    if (existing) return existing.replace(/^\s*\d+\s*/, '').trim() || existing;
    const h = el.querySelector('h1, h2, h3, [data-title]');
    const t = h && (h.textContent || '').trim().slice(0, 40);
    if (t) return t;
    return 'Slide';
  };
  const stylesheet = `
    :host {
      position: fixed;
      inset: 0;
      display: block;
      background: #000;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow: hidden;
      -webkit-tap-highlight-color: transparent;
    }
    /* connectedCallback holds this until document.fonts.ready (capped 2s) so
     * the first visible paint has the deck's real typography + final rail
     * layout. opacity (not visibility) so the active slide can't un-hide
     * itself via the ::slotted([data-deck-active]) visibility:visible rule.
     * Only the stage/rail hide — the black :host background stays, so the
     * iframe doesn't flash the page's default white. */
    :host([data-fonts-pending]) .stage,
    :host([data-fonts-pending]) .rail { opacity: 0; pointer-events: none; }

    .stage {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .canvas {
      position: relative;
      transform-origin: center center;
      flex-shrink: 0;
      background: #fff;
      will-change: transform;
    }

    /* Slides live in light DOM (via <slot>) so authored CSS still applies.
       We absolutely position each slotted child to stack them. */
    ::slotted(*) {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    ::slotted([data-deck-active]) {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
    }

    .overlay {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translate(-50%, 6px) scale(0.92);
      filter: blur(6px);
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px;
      background: #000;
      color: #fff;
      border-radius: 999px;
      font-size: 12px;
      font-feature-settings: "tnum" 1;
      letter-spacing: 0.01em;
      opacity: 0;
      pointer-events: none;
      transition: opacity 260ms ease, transform 260ms cubic-bezier(.2,.8,.2,1), filter 260ms ease;
      transform-origin: center bottom;
      z-index: 2147483000;
      user-select: none;
    }
    .overlay[data-visible] {
      opacity: 1;
      pointer-events: auto;
      transform: translate(-50%, 0) scale(1);
      filter: blur(0);
    }

    .btn {
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 0;
      margin: 0;
      padding: 0;
      color: inherit;
      font: inherit;
      cursor: default;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 28px;
      min-width: 28px;
      border-radius: 999px;
      color: rgba(255,255,255,0.72);
      transition: background 140ms ease, color 140ms ease;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .btn:active { background: rgba(255,255,255,0.18); }
    .btn:focus { outline: none; }
    .btn:focus-visible { outline: none; }
    .btn::-moz-focus-inner { border: 0; }
    .btn svg { width: 14px; height: 14px; display: block; }
    .btn.reset {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.02em;
      padding: 0 10px 0 12px;
      gap: 6px;
      color: rgba(255,255,255,0.72);
    }
    .btn.reset .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      font-size: 10px;
      line-height: 1;
      color: rgba(255,255,255,0.88);
      background: rgba(255,255,255,0.12);
      border-radius: 4px;
    }

    .count {
      font-variant-numeric: tabular-nums;
      color: #fff;
      font-weight: 500;
      padding: 0 8px;
      min-width: 42px;
      text-align: center;
      font-size: 12px;
    }
    .count .sep { color: rgba(255,255,255,0.45); margin: 0 3px; font-weight: 400; }
    .count .total { color: rgba(255,255,255,0.55); }

    .divider {
      width: 1px;
      height: 14px;
      background: rgba(255,255,255,0.18);
      margin: 0 2px;
    }

    /* ── Thumbnail rail ──────────────────────────────────────────────────
       Fixed column on the left; each thumbnail is a static deep-clone of
       the light-DOM slide scaled into a 16:9 (or design-aspect) frame. The
       stage re-fits around it (see _fit); hidden during present / noscale
       / print so capture geometry and fullscreen output are unchanged. */
    .rail {
      position: fixed;
      left: 0;
      top: 0;
      bottom: 0;
      width: var(--deck-rail-w, 188px);
      background: #141414;
      border-right: 1px solid rgba(255,255,255,0.08);
      overflow-y: auto;
      overflow-x: hidden;
      padding: 12px 10px;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 12px;
      z-index: 2147482500;
      scrollbar-width: thin;
      scrollbar-color: rgba(255,255,255,0.18) transparent;
    }
    .rail::-webkit-scrollbar { width: 8px; }
    .rail::-webkit-scrollbar-track { background: transparent; margin: 2px; }
    .rail::-webkit-scrollbar-thumb {
      background: rgba(255,255,255,0.18);
      border-radius: 4px;
      border: 2px solid transparent;
      background-clip: content-box;
    }
    .rail::-webkit-scrollbar-thumb:hover {
      background: rgba(255,255,255,0.28);
      border: 2px solid transparent;
      background-clip: content-box;
    }
    :host([no-rail]) .rail,
    :host([noscale]) .rail { display: none; }
    .rail[data-presenting] { display: none; }
    @media (max-width: 640px) {
      .rail, .rail-resize { display: none; }
    }
    /* User-driven show/hide (the TweaksPanel toggle) slides instead of
       popping. Transitions are gated on :host([data-rail-anim]) — set only
       for the 200ms around the toggle — so window-resize and rail-width
       drag (which also call _fit) don't lag behind the cursor. */
    .rail[data-user-hidden] { transform: translateX(-100%); }
    :host([data-rail-anim]) .rail { transition: transform 200ms cubic-bezier(.3,.7,.4,1); }
    :host([data-rail-anim]) .stage { transition: left 200ms cubic-bezier(.3,.7,.4,1); }
    :host([data-rail-anim]) .canvas { transition: transform 200ms cubic-bezier(.3,.7,.4,1); }
    /* transition shorthand replaces rather than merges — repeat the base
       .overlay opacity/transform/filter transitions so visibility changes
       during the 200ms toggle window still fade instead of popping. */
    :host([data-rail-anim]) .overlay {
      transition: margin-left 200ms cubic-bezier(.3,.7,.4,1),
                  opacity 260ms ease,
                  transform 260ms cubic-bezier(.2,.8,.2,1),
                  filter 260ms ease;
    }

    .thumb {
      position: relative;
      display: flex;
      align-items: flex-start;
      gap: 8px;
      cursor: pointer;
      user-select: none;
    }
    .thumb .num {
      width: 16px;
      flex-shrink: 0;
      font-size: 11px;
      font-weight: 500;
      text-align: right;
      color: rgba(255,255,255,0.55);
      padding-top: 2px;
      font-variant-numeric: tabular-nums;
    }
    .thumb .frame {
      position: relative;
      flex: 1;
      min-width: 0;
      aspect-ratio: var(--deck-aspect);
      background: #fff;
      border-radius: 4px;
      outline: 2px solid transparent;
      outline-offset: 0;
      overflow: hidden;
      transition: outline-color 120ms ease;
    }
    .thumb:hover .frame { outline-color: rgba(255,255,255,0.25); }
    .thumb { outline: none; }
    .thumb:focus-visible .frame { outline-color: rgba(255,255,255,0.5); }
    .thumb[data-current] .num { color: #fff; }
    .thumb[data-current] .frame { outline-color: #D97757; }
    .thumb[data-dragging] { opacity: 0.35; }
    .thumb::before {
      content: '';
      position: absolute;
      left: 24px;
      right: 0;
      height: 3px;
      border-radius: 2px;
      background: #D97757;
      opacity: 0;
      pointer-events: none;
    }
    .thumb[data-drop="before"]::before { top: -8px; opacity: 1; }
    .thumb[data-drop="after"]::before { bottom: -8px; opacity: 1; }
    .thumb[data-skip] .frame { opacity: 0.35; }
    .thumb[data-skip] .frame::after {
      content: 'Skipped';
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0,0,0,0.45);
      color: #fff;
      font-size: 10px;
      font-weight: 500;
      letter-spacing: 0.04em;
    }

    .ctxmenu {
      position: fixed;
      min-width: 150px;
      padding: 4px;
      background: #242424;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 7px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.45);
      z-index: 2147483100;
      display: none;
      font-size: 12px;
    }
    .ctxmenu[data-open] { display: block; }
    .ctxmenu button {
      display: block;
      width: 100%;
      appearance: none;
      border: 0;
      background: transparent;
      color: #e8e8e8;
      font: inherit;
      text-align: left;
      padding: 6px 10px;
      border-radius: 4px;
      cursor: pointer;
    }
    .ctxmenu button:hover:not(:disabled) { background: rgba(255,255,255,0.08); }
    .ctxmenu button:disabled { opacity: 0.35; cursor: default; }
    .ctxmenu hr {
      border: 0;
      border-top: 1px solid rgba(255,255,255,0.1);
      margin: 4px 2px;
    }

    .rail-resize {
      position: fixed;
      left: calc(var(--deck-rail-w, 188px) - 3px);
      top: 0;
      bottom: 0;
      width: 6px;
      cursor: col-resize;
      z-index: 2147482600;
      touch-action: none;
    }
    .rail-resize:hover,
    .rail-resize[data-dragging] { background: rgba(255,255,255,0.12); }
    :host([no-rail]) .rail-resize,
    :host([noscale]) .rail-resize,
    .rail[data-presenting] + .rail-resize,
    .rail[data-user-hidden] + .rail-resize { display: none; }

    /* Delete-confirm popup — matches the SPA's ConfirmDialog layout
       (title + message body, depressed footer with Cancel / Delete). */
    .confirm-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.45);
      z-index: 2147483200;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .confirm-backdrop[data-open] { display: flex; }
    .confirm {
      width: 320px;
      max-width: calc(100vw - 32px);
      background: #2a2a2a;
      color: #e8e8e8;
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 12px;
      box-shadow: 0 12px 32px rgba(0,0,0,0.5);
      overflow: hidden;
      font-family: inherit;
      animation: deck-confirm-in 0.18s ease;
    }
    @keyframes deck-confirm-in {
      from { opacity: 0; transform: scale(0.96); }
      to { opacity: 1; transform: scale(1); }
    }
    .confirm .body { padding: 20px 20px 16px; }
    .confirm .title { font-size: 14px; font-weight: 600; margin-bottom: 4px; }
    .confirm .msg { font-size: 13px; line-height: 1.5; color: rgba(255,255,255,0.65); }
    .confirm .footer {
      padding: 14px 20px;
      background: #1f1f1f;
      border-top: 1px solid rgba(255,255,255,0.08);
      display: flex;
      justify-content: flex-end;
      gap: 8px;
    }
    .confirm button {
      appearance: none;
      font: inherit;
      font-size: 13px;
      font-weight: 500;
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
    }
    .confirm .cancel {
      background: transparent;
      border: 0;
      color: rgba(255,255,255,0.8);
    }
    .confirm .cancel:hover { background: rgba(255,255,255,0.08); }
    .confirm .danger {
      background: #c96442;
      border: 1px solid rgba(0,0,0,0.15);
      color: #fff;
      box-shadow: 0 1px 3px rgba(166,50,68,0.3), 0 2px 6px rgba(166,50,68,0.18);
    }
    .confirm .danger:hover { background: #b5563a; }

    /* ── Print: one page per slide, no chrome ────────────────────────────
       The screen layout stacks every slide at inset:0 inside a scaled
       canvas; for print we want them in document flow at the authored
       design size so the browser paginates one slide per sheet. The
       @page size is set from the width/height attributes via the inline
       <style id="deck-stage-print-page"> that connectedCallback injects
       into <head> (the @page at-rule has no effect inside shadow DOM). */
    @media print {
      :host {
        position: static;
        inset: auto;
        background: none;
        overflow: visible;
        color: inherit;
      }
      .stage { position: static; display: block; }
      .canvas {
        transform: none !important;
        width: auto !important;
        height: auto !important;
        background: none;
        will-change: auto;
      }
      ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        width: var(--deck-design-w) !important;
        height: var(--deck-design-h) !important;
        box-sizing: border-box !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto;
        break-after: page;
        page-break-after: always;
        break-inside: avoid;
        overflow: hidden;
      }
      /* :last-child alone isn't enough once data-deck-skip hides the
         trailing slide(s) — the last *visible* slide still carries
         break-after:page and prints a blank sheet. _markLastVisible()
         maintains data-deck-last-visible on the last non-skipped slide. */
      ::slotted(*:last-child),
      ::slotted([data-deck-last-visible]) {
        break-after: auto;
        page-break-after: auto;
      }
      ::slotted([data-deck-skip]) { display: none !important; }
      .overlay, .rail, .rail-resize, .ctxmenu, .confirm-backdrop { display: none !important; }
    }
  `;
  class DeckStage extends HTMLElement {
    static get observedAttributes() {
      return ['width', 'height', 'noscale', 'no-rail'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._index = 0;
      this._slides = [];
      this._notes = [];
      this._hideTimer = null;
      this._mouseIdleTimer = null;
      this._menuIndex = -1;
      this._onKey = this._onKey.bind(this);
      this._onResize = this._onResize.bind(this);
      this._onSlotChange = this._onSlotChange.bind(this);
      this._onMouseMove = this._onMouseMove.bind(this);
      this._onTap = this._onTap.bind(this);
      this._onMessage = this._onMessage.bind(this);
      // Capture-phase close so a click anywhere dismisses the menu, but
      // ignore clicks that land inside the menu itself — otherwise the
      // capture handler runs before the menu's own (bubble) handler and
      // clears _menuIndex out from under it.
      this._onDocClick = e => {
        if (this._menu && e.composedPath && e.composedPath().includes(this._menu)) return;
        this._closeMenu();
      };
    }
    get designWidth() {
      return parseInt(this.getAttribute('width'), 10) || DESIGN_W_DEFAULT;
    }
    get designHeight() {
      return parseInt(this.getAttribute('height'), 10) || DESIGN_H_DEFAULT;
    }
    connectedCallback() {
      // Presenter-view popup loads deckUrl?_snthumb=...#N for its prev/cur/
      // next thumbnails — the rail has no business rendering inside those
      // (wrong scale, and it offsets the stage so the thumb shows a gutter).
      if (/[?&]_snthumb=/.test(location.search)) this.setAttribute('no-rail', '');
      this._render();
      this._loadNotes();
      this._syncPrintPageRule();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      window.addEventListener('mousemove', this._onMouseMove, {
        passive: true
      });
      window.addEventListener('message', this._onMessage);
      window.addEventListener('click', this._onDocClick, true);
      this.addEventListener('click', this._onTap);
      // Print lays every slide out as its own page, so [data-deck-active]-
      // gated entrance styles need the attribute on every slide (not just
      // the current one) or their content prints at the hidden base style.
      // The transient freeze style lands BEFORE the attributes so any
      // attribute-keyed transition fires at 0s (changing transition-
      // duration after a transition has started doesn't affect it).
      this._onBeforePrint = () => {
        if (this._freezeStyle) this._freezeStyle.remove();
        this._freezeStyle = document.createElement('style');
        this._freezeStyle.textContent = '*,*::before,*::after{transition-duration:0s !important}';
        document.head.appendChild(this._freezeStyle);
        this._slides.forEach(s => s.setAttribute('data-deck-active', ''));
      };
      this._onAfterPrint = () => {
        this._applyIndex({
          showOverlay: false,
          broadcast: false
        });
        if (this._freezeStyle) {
          this._freezeStyle.remove();
          this._freezeStyle = null;
        }
      };
      window.addEventListener('beforeprint', this._onBeforePrint);
      window.addEventListener('afterprint', this._onAfterPrint);
      // Initial collection + layout happens via slotchange, which fires on mount.
      this._enableRail();
      // Hold the stage hidden until webfonts are ready so the first visible
      // paint has the deck's real typography — the :not(:defined) guard in
      // the page HTML only covers custom-element upgrade, not font load.
      // Capped so a 404'd font URL can't blank the deck indefinitely.
      this.setAttribute('data-fonts-pending', '');
      const reveal = () => this.removeAttribute('data-fonts-pending');
      // rAF first: fonts.ready is a pre-resolved promise until layout has
      // resolved the slotted text's font-family and pushed a FontFace into
      // 'loading'. Reading it here in connectedCallback (parse-time) would
      // settle the race in a microtask before any font fetch starts.
      requestAnimationFrame(() => {
        Promise.race([document.fonts ? document.fonts.ready : Promise.resolve(), new Promise(r => setTimeout(r, 2000))]).then(reveal, reveal);
      });
    }
    _enableRail() {
      // Idempotent — older host builds still post __omelette_rail_enabled.
      // no-rail guard keeps the observers/stylesheet walk off the cheap path
      // for presenter-popup thumbnail iframes (up to 9 per view).
      if (this._railEnabled || this.hasAttribute('no-rail')) return;
      this._railEnabled = true;
      // Per-viewer preference — restored alongside rail width. Default on;
      // only a stored '0' (from the TweaksPanel toggle) hides it.
      this._railVisible = true;
      try {
        if (localStorage.getItem('deck-stage.railVisible') === '0') this._railVisible = false;
      } catch (e) {}
      // Live thumbnail updates: watch the light-DOM slides for content
      // edits and re-clone just the affected thumb(s), debounced. Ignore
      // the data-deck-* / data-screen-label / data-om-validate attributes
      // this component itself writes so nav and skip don't trigger
      // spurious refreshes.
      const OWN_ATTRS = /^data-(deck-|screen-label$|om-validate$)/;
      this._liveDirty = new Set();
      this._liveObserver = new MutationObserver(records => {
        for (const r of records) {
          if (r.type === 'attributes' && OWN_ATTRS.test(r.attributeName || '')) continue;
          let n = r.target;
          while (n && n.parentElement !== this) n = n.parentElement;
          if (n && this._slideSet && this._slideSet.has(n)) this._liveDirty.add(n);
        }
        if (this._liveDirty.size && !this._liveTimer) {
          this._liveTimer = setTimeout(() => {
            this._liveTimer = null;
            this._liveDirty.forEach(s => this._refreshThumb(s));
            this._liveDirty.clear();
          }, 200);
        }
      });
      this._liveObserver.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      // Lazy thumbnail materialization — clone the slide only when its
      // frame scrolls into (or near) the rail viewport. rootMargin gives
      // ~4 thumbs of pre-load so fast scrolling doesn't flash blanks.
      this._railObserver = new IntersectionObserver(entries => {
        entries.forEach(e => {
          if (e.isIntersecting && e.target.__deckThumb) {
            this._materialize(e.target.__deckThumb);
          }
        });
      }, {
        root: this._rail,
        rootMargin: '400px 0px'
      });
      // Tweaks typically change CSS vars / attrs OUTSIDE <deck-stage>
      // (on <html>, <body>, a wrapper div, or a <style> tag), which
      // _liveObserver can't see. Re-snapshot author CSS (constructable
      // sheet is shared by reference, so one replaceSync updates every
      // thumb shadow root) and re-sync each thumb host's attrs + custom
      // properties. In-slide DOM mutations are _liveObserver's job.
      // Debounced so slider drags don't thrash.
      this._onTweakChange = () => {
        clearTimeout(this._tweakTimer);
        this._tweakTimer = setTimeout(() => {
          this._snapshotAuthorCss();
          // One getComputedStyle for the whole batch — each
          // getPropertyValue read below reuses the same computed style
          // as long as nothing invalidates layout between thumbs.
          const cs = getComputedStyle(this);
          (this._thumbs || []).forEach(t => {
            if (t.host) this._syncThumbHostAttrs(t.host, cs);
          });
        }, 120);
      };
      window.addEventListener('tweakchange', this._onTweakChange);
      this._snapshotAuthorCss();
      // Build the rail now that it's enabled — slotchange already fired,
      // so _renderRail's early-return skipped the initial build.
      this._syncRailHidden();
      this._renderRail();
      this._fit();
    }

    /** Snapshot document stylesheets into a constructable sheet that each
     *  thumbnail's nested shadow root adopts — so author CSS styles the
     *  cloned slide content without touching this component's chrome.
     *  Cross-origin sheets throw on .cssRules — skip them. Re-callable:
     *  the existing constructable sheet is reused via replaceSync so every
     *  already-adopted shadow root picks up the fresh CSS without re-adopt. */
    _snapshotAuthorCss() {
      // :root in an adopted sheet inside a shadow root matches nothing
      // (only the document root qualifies), so author rules like
      // `:root[data-voice="modern"] .serif` never reach the clones.
      // Rewrite :root → :host and mirror <html>'s data-*/class/lang onto
      // each thumb host (see _syncThumbHostAttrs) so the same selectors
      // match inside the thumbnail's shadow tree.
      const authorCss = Array.from(document.styleSheets).map(sh => {
        try {
          return Array.from(sh.cssRules).map(r => r.cssText).join('\n');
        } catch (e) {
          return '';
        }
      }).join('\n')
      // The shadow host is featureless outside the functional :host(...)
      // form, so any compound on :root — [attr], .class, #id, :pseudo —
      // must become :host(<compound>) not :host<compound>. Same for the
      // html type selector (Tailwind class-strategy dark mode emits
      // html.dark; Pico uses html[data-theme]), which has nothing to
      // match inside the thumb's shadow tree.
      .replace(/:root((?:\[[^\]]*\]|[.#][-\w]+|:[-\w]+(?:\([^)]*\))?)+)/g, ':host($1)').replace(/:root\b/g, ':host').replace(/(^|[\s,>~+(}])html((?:\[[^\]]*\]|[.#][-\w]+|:[-\w]+(?:\([^)]*\))?)+)(?![-\w])/g, '$1:host($2)').replace(/(^|[\s,>~+(}])html(?![-\w])/g, '$1:host');
      // Every custom property the author references. _syncThumbHostAttrs
      // mirrors each one's *computed* value at <deck-stage> onto the
      // thumb host so the live value wins over the :host default above
      // regardless of which ancestor the tweak wrote to (<html>, <body>,
      // a wrapper div, or the deck-stage element itself all inherit
      // down to getComputedStyle(this)).
      this._authorVars = new Set(authorCss.match(/--[\w-]+/g) || []);
      try {
        if (!this._adoptedSheet) this._adoptedSheet = new CSSStyleSheet();
        this._adoptedSheet.replaceSync(authorCss);
      } catch (e) {
        this._adoptedSheet = null;
        this._authorCss = authorCss;
      }
    }
    _syncThumbHostAttrs(host, cs) {
      const de = document.documentElement;
      // setAttribute overwrites but can't delete — an attr removed from
      // <html> (toggleAttribute off, classList emptied) would linger on
      // the host and :host([data-*]) / :host(.foo) rules would keep
      // matching. Remove stale mirrored attrs first; iterate backward
      // because removeAttribute mutates the live NamedNodeMap.
      for (let i = host.attributes.length - 1; i >= 0; i--) {
        const n = host.attributes[i].name;
        if ((n.startsWith('data-') || n === 'class' || n === 'lang') && !de.hasAttribute(n)) {
          host.removeAttribute(n);
        }
      }
      for (const a of de.attributes) {
        if (a.name.startsWith('data-') || a.name === 'class' || a.name === 'lang') {
          host.setAttribute(a.name, a.value);
        }
      }
      // The :root→:host rewrite in _snapshotAuthorCss pins each custom
      // property to its stylesheet default on the thumb host, shadowing
      // the live value that would otherwise inherit. Tweaks can write the
      // live value on any ancestor — <html>, <body>, a wrapper div, the
      // deck-stage element — so read it as the *computed* value at
      // <deck-stage> (which sees the whole inheritance chain) rather than
      // trying to guess which element the author wrote to. Inline on the
      // host beats the :host{} rule. remove-stale covers vars dropped
      // from the stylesheet between snapshots.
      const vars = this._authorVars || new Set();
      for (let i = host.style.length - 1; i >= 0; i--) {
        const p = host.style[i];
        if (p.startsWith('--') && !vars.has(p)) host.style.removeProperty(p);
      }
      const live = cs || getComputedStyle(this);
      vars.forEach(p => {
        const v = live.getPropertyValue(p);
        if (v) host.style.setProperty(p, v.trim());else host.style.removeProperty(p);
      });
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      window.removeEventListener('mousemove', this._onMouseMove);
      window.removeEventListener('message', this._onMessage);
      window.removeEventListener('click', this._onDocClick, true);
      window.removeEventListener('beforeprint', this._onBeforePrint);
      window.removeEventListener('afterprint', this._onAfterPrint);
      if (this._freezeStyle) {
        this._freezeStyle.remove();
        this._freezeStyle = null;
      }
      this.removeEventListener('click', this._onTap);
      if (this._hideTimer) clearTimeout(this._hideTimer);
      if (this._mouseIdleTimer) clearTimeout(this._mouseIdleTimer);
      if (this._liveTimer) clearTimeout(this._liveTimer);
      if (this._tweakTimer) clearTimeout(this._tweakTimer);
      if (this._railAnimTimer) clearTimeout(this._railAnimTimer);
      if (this._scaleRaf) cancelAnimationFrame(this._scaleRaf);
      if (this._liveObserver) this._liveObserver.disconnect();
      if (this._railObserver) this._railObserver.disconnect();
      if (this._onTweakChange) window.removeEventListener('tweakchange', this._onTweakChange);
    }
    attributeChangedCallback() {
      if (this._canvas) {
        this._canvas.style.width = this.designWidth + 'px';
        this._canvas.style.height = this.designHeight + 'px';
        this._canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
        this._canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
        if (this._rail) {
          this._rail.style.setProperty('--deck-aspect', this.designWidth + '/' + this.designHeight);
        }
        this._fit();
        this._scaleThumbs();
        this._syncPrintPageRule();
      }
    }
    _render() {
      const style = document.createElement('style');
      style.textContent = stylesheet;
      const stage = document.createElement('div');
      stage.className = 'stage';
      const canvas = document.createElement('div');
      canvas.className = 'canvas';
      canvas.style.width = this.designWidth + 'px';
      canvas.style.height = this.designHeight + 'px';
      canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
      canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
      const slot = document.createElement('slot');
      slot.addEventListener('slotchange', this._onSlotChange);
      canvas.appendChild(slot);
      stage.appendChild(canvas);

      // Overlay: compact, solid black, with clickable controls.
      const overlay = document.createElement('div');
      overlay.className = 'overlay export-hidden';
      overlay.setAttribute('role', 'toolbar');
      overlay.setAttribute('aria-label', 'Deck controls');
      overlay.setAttribute('data-omelette-chrome', '');
      overlay.innerHTML = `
        <button class="btn prev" type="button" aria-label="Previous slide" title="Previous (←)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3L5 8l5 5"/></svg>
        </button>
        <span class="count" aria-live="polite"><span class="current">1</span><span class="sep">/</span><span class="total">1</span></span>
        <button class="btn next" type="button" aria-label="Next slide" title="Next (→)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3l5 5-5 5"/></svg>
        </button>
        <span class="divider"></span>
        <button class="btn reset" type="button" aria-label="Reset to first slide" title="Reset (R)">Reset<span class="kbd">R</span></button>
      `;
      overlay.querySelector('.prev').addEventListener('click', () => this._advance(-1, 'click'));
      overlay.querySelector('.next').addEventListener('click', () => this._advance(1, 'click'));
      overlay.querySelector('.reset').addEventListener('click', () => this._go(0, 'click'));

      // Thumbnail rail + context menu. Thumbnails are populated in
      // _renderRail() after _collectSlides().
      const rail = document.createElement('div');
      rail.className = 'rail export-hidden';
      rail.setAttribute('data-omelette-chrome', '');
      rail.style.setProperty('--deck-aspect', this.designWidth + '/' + this.designHeight);
      // Edge auto-scroll while dragging a thumb near the rail's top/bottom
      // so off-screen drop targets are reachable. Native dragover fires
      // continuously while the pointer is stationary, so a per-event nudge
      // (ramped by edge proximity) is enough — no rAF loop needed.
      rail.addEventListener('dragover', e => {
        if (this._dragFrom == null) return;
        const r = rail.getBoundingClientRect();
        const EDGE = 40;
        const dt = e.clientY - r.top;
        const db = r.bottom - e.clientY;
        if (dt < EDGE) rail.scrollTop -= Math.ceil((EDGE - dt) / 3);else if (db < EDGE) rail.scrollTop += Math.ceil((EDGE - db) / 3);
      });
      const menu = document.createElement('div');
      menu.className = 'ctxmenu export-hidden';
      menu.setAttribute('data-omelette-chrome', '');
      menu.innerHTML = `
        <button type="button" data-act="skip">Skip slide</button>
        <button type="button" data-act="up">Move up</button>
        <button type="button" data-act="down">Move down</button>
        <hr>
        <button type="button" data-act="delete">Delete slide</button>
      `;
      menu.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        const i = this._menuIndex;
        this._closeMenu();
        if (act === 'skip') this._toggleSkip(i);else if (act === 'up') this._moveSlide(i, i - 1);else if (act === 'down') this._moveSlide(i, i + 1);else if (act === 'delete') this._openConfirm(i);
      });
      menu.addEventListener('contextmenu', e => e.preventDefault());

      // Rail resize handle — drag to set --deck-rail-w, persisted to
      // localStorage so the width survives reloads.
      const resize = document.createElement('div');
      resize.className = 'rail-resize export-hidden';
      resize.setAttribute('data-omelette-chrome', '');
      resize.addEventListener('pointerdown', e => {
        e.preventDefault();
        resize.setPointerCapture(e.pointerId);
        resize.setAttribute('data-dragging', '');
        const move = ev => this._setRailWidth(ev.clientX);
        const up = () => {
          resize.removeEventListener('pointermove', move);
          resize.removeEventListener('pointerup', up);
          resize.removeEventListener('pointercancel', up);
          resize.removeAttribute('data-dragging');
          try {
            localStorage.setItem('deck-stage.railWidth', String(this._railPx));
          } catch (err) {}
        };
        resize.addEventListener('pointermove', move);
        resize.addEventListener('pointerup', up);
        resize.addEventListener('pointercancel', up);
      });

      // Delete-confirm dialog — mirrors the SPA's ConfirmDialog layout.
      const confirm = document.createElement('div');
      confirm.className = 'confirm-backdrop export-hidden';
      confirm.setAttribute('data-omelette-chrome', '');
      confirm.innerHTML = `
        <div class="confirm" role="dialog" aria-modal="true">
          <div class="body">
            <div class="title">Delete slide?</div>
            <div class="msg">This slide will be removed from the deck.</div>
          </div>
          <div class="footer">
            <button type="button" class="cancel">Cancel</button>
            <button type="button" class="danger">Delete</button>
          </div>
        </div>
      `;
      confirm.addEventListener('click', e => {
        if (e.target === confirm) this._closeConfirm();
      });
      confirm.querySelector('.cancel').addEventListener('click', () => this._closeConfirm());
      confirm.querySelector('.danger').addEventListener('click', () => {
        const i = this._confirmIndex;
        this._closeConfirm();
        this._deleteSlide(i);
      });
      this._root.append(style, rail, resize, stage, overlay, menu, confirm);
      this._canvas = canvas;
      this._stage = stage;
      this._slot = slot;
      this._overlay = overlay;
      this._rail = rail;
      this._resize = resize;
      this._menu = menu;
      this._confirm = confirm;
      this._countEl = overlay.querySelector('.current');
      this._totalEl = overlay.querySelector('.total');

      // Restore persisted rail width.
      let rw = 188;
      try {
        const s = localStorage.getItem('deck-stage.railWidth');
        if (s) rw = parseInt(s, 10) || rw;
      } catch (err) {}
      this._setRailWidth(rw);
      this._syncRailHidden();
    }
    _setRailWidth(px) {
      const w = Math.max(120, Math.min(360, Math.round(px)));
      this._railPx = w;
      this.style.setProperty('--deck-rail-w', w + 'px');
      this._fit();
      // _scaleThumbs forces a sync layout (frame.offsetWidth) then writes
      // N transforms. During a resize drag this runs per-pointermove;
      // coalesce to one per frame.
      if (!this._scaleRaf) {
        this._scaleRaf = requestAnimationFrame(() => {
          this._scaleRaf = null;
          this._scaleThumbs();
        });
      }
    }

    /** @page must live in the document stylesheet — it's a no-op inside
     *  shadow DOM. Inject/update a single <head> style tag so the print
     *  sheet matches the design size and Save-as-PDF yields one slide per
     *  page with no margins. */
    _syncPrintPageRule() {
      const id = 'deck-stage-print-page';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
        document.head.appendChild(tag);
      }
      tag.textContent = '@page { size: ' + this.designWidth + 'px ' + this.designHeight + 'px; margin: 0; } ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; overflow: visible !important; height: auto !important; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } ' +
      // Jump authored animations/transitions to their end state so print
      // never captures mid-entrance — pairs with the beforeprint handler
      // in connectedCallback that sets data-deck-active on every slide.
      '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }
    _onSlotChange() {
      // Rail mutations (delete/move) already reconcile synchronously and
      // emit slidechange with reason 'api'; skip the async slotchange that
      // would otherwise re-broadcast with reason 'init'.
      if (this._squelchSlotChange) {
        this._squelchSlotChange = false;
        return;
      }
      this._collectSlides();
      this._restoreIndex();
      this._applyIndex({
        showOverlay: false,
        broadcast: true,
        reason: 'init'
      });
      this._fit();
    }
    _collectSlides() {
      const assigned = this._slot.assignedElements({
        flatten: true
      });
      this._slides = assigned.filter(el => {
        // Skip template/style/script nodes even if someone slots them.
        const tag = el.tagName;
        return tag !== 'TEMPLATE' && tag !== 'SCRIPT' && tag !== 'STYLE';
      });
      this._slideSet = new Set(this._slides);
      this._slides.forEach((slide, i) => {
        const n = i + 1;
        slide.setAttribute('data-screen-label', `${pad2(n)} ${getSlideLabel(slide)}`);

        // Validation attribute for comment flow / auto-checks.
        if (!slide.hasAttribute('data-om-validate')) {
          slide.setAttribute('data-om-validate', VALIDATE_ATTR);
        }
        slide.setAttribute('data-deck-slide', String(i));
      });
      if (this._totalEl) this._totalEl.textContent = String(this._slides.length || 1);
      if (this._index >= this._slides.length) this._index = Math.max(0, this._slides.length - 1);
      this._markLastVisible();
      this._renderRail();
    }

    /** Tag the last non-skipped slide so print CSS can drop its
     *  break-after (see the @media print comment above — :last-child
     *  alone matches a hidden skipped slide). */
    _markLastVisible() {
      let last = null;
      this._slides.forEach(s => {
        s.removeAttribute('data-deck-last-visible');
        if (!s.hasAttribute('data-deck-skip')) last = s;
      });
      if (last) last.setAttribute('data-deck-last-visible', '');
    }
    _loadNotes() {
      const tag = document.getElementById('speaker-notes');
      if (!tag) {
        this._notes = [];
        return;
      }
      try {
        const parsed = JSON.parse(tag.textContent || '[]');
        if (Array.isArray(parsed)) this._notes = parsed;
      } catch (e) {
        console.warn('[deck-stage] Failed to parse #speaker-notes JSON:', e);
        this._notes = [];
      }
    }
    _restoreIndex() {
      // The host's ?slide= param is delivered as a #<int> hash (1-indexed) on
      // the iframe src. No hash → slide 1; the deck itself keeps no position
      // state across loads.
      const h = (location.hash || '').match(/^#(\d+)$/);
      if (h) {
        const n = parseInt(h[1], 10) - 1;
        if (n >= 0 && n < this._slides.length) this._index = n;
      }
    }
    _applyIndex({
      showOverlay = true,
      broadcast = true,
      reason = 'init'
    } = {}) {
      if (!this._slides.length) return;
      const prev = this._prevIndex == null ? -1 : this._prevIndex;
      const curr = this._index;
      // Keep the iframe's own hash in sync so an in-iframe location.reload()
      // (reload banner path in viewer-handle.ts) lands on the current slide,
      // not the stale deep-link hash from initial load.
      try {
        history.replaceState(null, '', '#' + (curr + 1));
      } catch (e) {}
      this._slides.forEach((s, i) => {
        if (i === curr) s.setAttribute('data-deck-active', '');else s.removeAttribute('data-deck-active');
      });
      if (this._countEl) this._countEl.textContent = String(curr + 1);
      // Follow-scroll on every navigation (init deep-link, keyboard, click,
      // tap, external goTo) — the only time we *don't* want the rail to
      // track current is after a rail-internal mutation, where _renderRail
      // has already restored the user's scroll position and yanking back to
      // current would undo it.
      this._syncRail(reason !== 'mutation');
      if (broadcast) {
        // (1) Legacy: host-window postMessage for speaker-notes renderers.
        try {
          window.postMessage({
            slideIndexChanged: curr,
            deckTotal: this._slides.length,
            deckSkipped: this._skippedIndices()
          }, '*');
        } catch (e) {}

        // (2) In-page CustomEvent on the <deck-stage> element itself.
        //     Bubbles and composes out of shadow DOM so slide code can listen:
        //       document.querySelector('deck-stage').addEventListener('slidechange', e => {
        //         e.detail.index, e.detail.previousIndex, e.detail.total, e.detail.slide, e.detail.reason
        //       });
        const detail = {
          index: curr,
          previousIndex: prev,
          total: this._slides.length,
          slide: this._slides[curr] || null,
          previousSlide: prev >= 0 ? this._slides[prev] || null : null,
          reason: reason // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
        };
        this.dispatchEvent(new CustomEvent('slidechange', {
          detail,
          bubbles: true,
          composed: true
        }));
      }
      this._prevIndex = curr;
      if (showOverlay) this._flashOverlay();
    }
    _flashOverlay() {
      // Host posts __omelette_presenting while in fullscreen/tab presentation
      // mode — suppress the nav footer entirely (both hover and slide-change
      // flash) so the audience sees clean slides.
      if (!this._overlay || this._presenting) return;
      this._overlay.setAttribute('data-visible', '');
      if (this._hideTimer) clearTimeout(this._hideTimer);
      this._hideTimer = setTimeout(() => {
        this._overlay.removeAttribute('data-visible');
      }, OVERLAY_HIDE_MS);
    }
    _railWidth() {
      // State-based, no offsetWidth: the first _fit() can run before the
      // rail has had layout on some load paths, and a 0 there paints the
      // slide full-width for one frame before the post-slotchange _fit()
      // corrects it.
      if (!this._railEnabled || !this._railVisible || this.hasAttribute('no-rail') || this.hasAttribute('noscale') || this._presenting || this._previewMode || NARROW_MQ.matches) return 0;
      return this._railPx || 0;
    }
    _fit() {
      if (!this._canvas) return;
      const stage = this._canvas.parentElement;
      // PPTX export sets noscale so the DOM capture sees authored-size
      // geometry — the scaled canvas is in shadow DOM, so the exporter's
      // resetTransformSelector can't reach .canvas.style.transform directly.
      if (this.hasAttribute('noscale')) {
        this._canvas.style.transform = 'none';
        if (stage) stage.style.left = '0';
        if (this._overlay) this._overlay.style.marginLeft = '0';
        return;
      }
      const rw = this._railWidth();
      if (stage) stage.style.left = rw + 'px';
      // Overlay is centred on the viewport via left:50% + translate(-50%);
      // marginLeft shifts the centre by rw/2 so it lands in the middle of
      // the [rw, innerWidth] stage region.
      if (this._overlay) this._overlay.style.marginLeft = rw / 2 + 'px';
      const vw = window.innerWidth - rw;
      const vh = window.innerHeight;
      const s = Math.min(vw / this.designWidth, vh / this.designHeight);
      this._canvas.style.transform = `scale(${s})`;
    }
    _onResize() {
      this._fit();
      // Crossing the narrow-viewport breakpoint reveals the rail — rerun the
      // thumbnail scale the same way _setRailWidth does.
      if (!this._scaleRaf) {
        this._scaleRaf = requestAnimationFrame(() => {
          this._scaleRaf = null;
          this._scaleThumbs();
        });
      }
    }
    _onMouseMove() {
      // Keep overlay visible while mouse moves; hide after idle.
      this._flashOverlay();
    }
    _onMessage(e) {
      const d = e.data;
      if (d && typeof d.__omelette_presenting === 'boolean') {
        this._presenting = d.__omelette_presenting;
        if (this._presenting && this._overlay) {
          this._overlay.removeAttribute('data-visible');
          if (this._hideTimer) clearTimeout(this._hideTimer);
        }
        this._syncRailHidden();
        this._closeMenu();
        this._closeConfirm();
        this._fit();
        this._scaleThumbs();
      }
      // Host's Preview segment (ViewerMode='none'): the rail's drag-reorder /
      // right-click skip-delete affordances are editing chrome, so hide it
      // while the user is just looking at the deck. Same hard-hide path as
      // presenting; independent of the user's _railVisible preference so
      // returning to Edit restores whatever they had.
      if (d && typeof d.__omelette_preview_mode === 'boolean') {
        if (d.__omelette_preview_mode === this._previewMode) return;
        this._previewMode = d.__omelette_preview_mode;
        this._syncRailHidden();
        this._closeMenu();
        this._closeConfirm();
        this._fit();
        this._scaleThumbs();
      }
      // Per-viewer show/hide, driven by the TweaksPanel's auto-injected
      // "Thumbnail rail" toggle (or any author script). Independent of
      // whether the Tweaks panel itself is open — closing the panel
      // doesn't change rail visibility. Persists alongside rail width.
      if (d && d.type === '__deck_rail_visible' && typeof d.on === 'boolean') {
        if (d.on === this._railVisible) return;
        this._railVisible = d.on;
        try {
          localStorage.setItem('deck-stage.railVisible', d.on ? '1' : '0');
        } catch (e) {}
        // Arm the transition, commit it, then flip state — otherwise the
        // browser coalesces both writes and nothing animates on show.
        this.setAttribute('data-rail-anim', '');
        void (this._rail && this._rail.offsetHeight);
        this._syncRailHidden();
        this._fit();
        this._scaleThumbs();
        clearTimeout(this._railAnimTimer);
        this._railAnimTimer = setTimeout(() => this.removeAttribute('data-rail-anim'), 220);
      }
      if (d && d.type === '__omelette_rail_enabled') this._enableRail();
    }
    _syncRailHidden() {
      if (!this._rail) return;
      // data-presenting is the hard hide (display:none) for flag-off,
      // presentation mode, and the host's Preview segment — instant, no
      // transition. data-user-hidden is the soft hide (translateX(-100%))
      // for the viewer's rail toggle, so show/hide slides under
      // :host([data-rail-anim]).
      const hard = !this._railEnabled || this._presenting || this._previewMode;
      if (hard) this._rail.setAttribute('data-presenting', '');else this._rail.removeAttribute('data-presenting');
      if (!this._railVisible) this._rail.setAttribute('data-user-hidden', '');else this._rail.removeAttribute('data-user-hidden');
      // translateX hide leaves thumbs (tabIndex=0) in the tab order —
      // inert keeps them unfocusable while the rail is off-screen.
      this._rail.inert = hard || !this._railVisible;
    }
    _onTap(e) {
      // Touch-only — keyboard + the overlay toolbar cover nav on desktop.
      if (FINE_POINTER_MQ.matches) return;
      // Only taps that land on the stage (slide content or letterbox); the
      // overlay / rail / menus are siblings with their own click handlers.
      const path = e.composedPath();
      if (!this._stage || !path.includes(this._stage)) return;
      // Let interactive slide content keep the tap. composedPath (not
      // e.target.closest) so we see through open shadow roots — a <button>
      // inside a slide-authored custom element retargets e.target to the
      // host but still appears in the composed path.
      if (e.defaultPrevented) return;
      for (const n of path) {
        if (n === this._stage) break;
        if (n.matches && n.matches(INTERACTIVE_SEL)) return;
      }
      e.preventDefault();
      const rw = this._railWidth();
      const mid = rw + (window.innerWidth - rw) / 2;
      this._advance(e.clientX < mid ? -1 : 1, 'tap');
    }
    _onKey(e) {
      // Ignore when the user is typing.
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      // Confirm dialog swallows nav keys while open; Escape cancels. Enter
      // is left to the focused button's native activation so Tab→Cancel
      // →Enter activates Cancel, not the window-level confirm path.
      if (this._confirm && this._confirm.hasAttribute('data-open')) {
        if (e.key === 'Escape') {
          this._closeConfirm();
          e.preventDefault();
        }
        return;
      }
      if (e.key === 'Escape' && this._menu && this._menu.hasAttribute('data-open')) {
        this._closeMenu();
        e.preventDefault();
        return;
      }
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const key = e.key;
      let handled = true;
      if (key === 'ArrowRight' || key === 'PageDown' || key === ' ' || key === 'Spacebar') {
        this._advance(1, 'keyboard');
      } else if (key === 'ArrowLeft' || key === 'PageUp') {
        this._advance(-1, 'keyboard');
      } else if (key === 'Home') {
        this._go(0, 'keyboard');
      } else if (key === 'End') {
        this._go(this._slides.length - 1, 'keyboard');
      } else if (key === 'r' || key === 'R') {
        this._go(0, 'keyboard');
      } else if (/^[0-9]$/.test(key)) {
        // 1..9 jump to that slide; 0 jumps to 10.
        const n = key === '0' ? 9 : parseInt(key, 10) - 1;
        if (n < this._slides.length) this._go(n, 'keyboard');
      } else {
        handled = false;
      }
      if (handled) {
        e.preventDefault();
        this._flashOverlay();
      }
    }
    _go(i, reason = 'api') {
      if (!this._slides.length) return;
      const clamped = Math.max(0, Math.min(this._slides.length - 1, i));
      if (clamped === this._index) {
        this._flashOverlay();
        return;
      }
      this._index = clamped;
      this._applyIndex({
        showOverlay: true,
        broadcast: true,
        reason
      });
    }

    /** Step forward/back skipping any slide marked data-deck-skip. Falls
     *  back to _go's clamp-at-ends behaviour (flash overlay) when there's
     *  nothing further in that direction. */
    _advance(dir, reason) {
      if (!this._slides.length) return;
      let i = this._index + dir;
      while (i >= 0 && i < this._slides.length && this._slides[i].hasAttribute('data-deck-skip')) {
        i += dir;
      }
      if (i < 0 || i >= this._slides.length) {
        this._flashOverlay();
        return;
      }
      this._go(i, reason);
    }

    // ── Thumbnail rail ────────────────────────────────────────────────────
    //
    // Thumbs are keyed by slide element and reused across _renderRail()
    // calls, so a reorder/delete is an O(changed) DOM shuffle instead of an
    // O(N) teardown-and-re-clone. Each thumb starts as a lightweight shell
    // (num + empty frame); the clone is materialized lazily by an
    // IntersectionObserver when the frame scrolls into (or near) view, so
    // only visible-ish slides pay the clone + image-decode cost.

    _renderRail() {
      if (!this._rail || !this._railEnabled) {
        this._thumbs = [];
        return;
      }
      // FLIP: record each *materialized* thumb's top before the reconcile.
      // Off-screen (non-materialized) thumbs don't need the animation and
      // skipping their getBoundingClientRect saves a forced layout per
      // off-screen thumb on large decks.
      const prevTops = new Map();
      (this._thumbs || []).forEach(({
        thumb,
        slide,
        host
      }) => {
        if (host) prevTops.set(slide, thumb.getBoundingClientRect().top);
      });
      const st = this._rail.scrollTop;

      // Reconcile: reuse thumbs that already exist for a slide, create
      // shells for new slides, drop thumbs for removed slides.
      const bySlide = new Map();
      (this._thumbs || []).forEach(t => bySlide.set(t.slide, t));
      const next = [];
      this._slides.forEach(slide => {
        let t = bySlide.get(slide);
        if (t) bySlide.delete(slide);else t = this._makeThumb(slide);
        next.push(t);
      });
      // Orphans — slides removed since last render.
      bySlide.forEach(t => {
        if (this._railObserver) this._railObserver.unobserve(t.frame);
        t.thumb.remove();
      });
      // Put thumbs into document order to match _slides. insertBefore on
      // an already-correctly-placed node is a no-op, so this is cheap
      // when nothing moved.
      next.forEach((t, i) => {
        const want = t.thumb;
        const at = this._rail.children[i];
        if (at !== want) this._rail.insertBefore(want, at || null);
        t.i = i;
        t.num.textContent = String(i + 1);
        if (t.slide.hasAttribute('data-deck-skip')) t.thumb.setAttribute('data-skip', '');else t.thumb.removeAttribute('data-skip');
      });
      this._thumbs = next;
      this._rail.scrollTop = st;
      if (prevTops.size) {
        const moved = [];
        this._thumbs.forEach(({
          thumb,
          slide
        }) => {
          const old = prevTops.get(slide);
          if (old == null) return;
          const dy = old - thumb.getBoundingClientRect().top;
          if (Math.abs(dy) < 1) return;
          thumb.style.transition = 'none';
          thumb.style.transform = `translateY(${dy}px)`;
          moved.push(thumb);
        });
        if (moved.length) {
          // Commit the inverted positions before flipping the transition
          // on — otherwise the browser coalesces both style writes and
          // nothing animates.
          void this._rail.offsetHeight;
          moved.forEach(t => {
            t.style.transition = 'transform 180ms cubic-bezier(.2,.7,.3,1)';
            t.style.transform = '';
          });
          setTimeout(() => moved.forEach(t => {
            t.style.transition = '';
          }), 220);
        }
      }
      requestAnimationFrame(() => this._scaleThumbs());
      this._syncRail(false);
    }

    /** Create a lightweight thumb shell for one slide. The clone is
     *  materialized later by the IntersectionObserver. Event handlers
     *  look up the thumb's *current* index (via _thumbs.indexOf) so the
     *  same element can be reused across reorders. */
    _makeThumb(slide) {
      const thumb = document.createElement('div');
      thumb.className = 'thumb';
      thumb.tabIndex = 0;
      const num = document.createElement('div');
      num.className = 'num';
      const frame = document.createElement('div');
      frame.className = 'frame';
      thumb.append(num, frame);
      const entry = {
        thumb,
        num,
        frame,
        slide,
        clone: null,
        host: null,
        i: -1
      };
      // entry.i is refreshed on every _renderRail reconcile pass, so
      // handlers read the thumb's current position without an O(N) scan.
      const idx = () => entry.i;
      thumb.addEventListener('click', () => this._go(idx(), 'click'));
      // ↑/↓ step through the rail when a thumb has focus. _go clamps at the
      // ends and _applyIndex→_syncRail scrolls the new current thumb into
      // view; we move focus to it (preventScroll — _syncRail already
      // scrolled) so a held key walks the whole list. stopPropagation keeps
      // this out of the window-level _onKey nav handler.
      thumb.addEventListener('keydown', e => {
        if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
        if (e.metaKey || e.ctrlKey || e.altKey) return;
        e.preventDefault();
        e.stopPropagation();
        this._go(idx() + (e.key === 'ArrowDown' ? 1 : -1), 'keyboard');
        const cur = this._thumbs && this._thumbs[this._index];
        if (cur) cur.thumb.focus({
          preventScroll: true
        });
      });
      thumb.addEventListener('contextmenu', e => {
        e.preventDefault();
        this._openMenu(idx(), e.clientX, e.clientY);
      });
      thumb.draggable = true;
      thumb.addEventListener('dragstart', e => {
        this._dragFrom = idx();
        thumb.setAttribute('data-dragging', '');
        e.dataTransfer.effectAllowed = 'move';
        try {
          e.dataTransfer.setData('text/plain', String(this._dragFrom));
        } catch (err) {}
      });
      thumb.addEventListener('dragend', () => {
        thumb.removeAttribute('data-dragging');
        this._clearDrop();
        this._dragFrom = null;
      });
      thumb.addEventListener('dragover', e => {
        if (this._dragFrom == null) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        const r = thumb.getBoundingClientRect();
        this._setDrop(idx(), e.clientY < r.top + r.height / 2 ? 'before' : 'after');
      });
      thumb.addEventListener('drop', e => {
        if (this._dragFrom == null) return;
        e.preventDefault();
        const i = idx();
        const r = thumb.getBoundingClientRect();
        let to = e.clientY >= r.top + r.height / 2 ? i + 1 : i;
        if (this._dragFrom < to) to--;
        const from = this._dragFrom;
        this._clearDrop();
        this._dragFrom = null;
        if (to !== from) this._moveSlide(from, to);
      });
      if (this._railObserver) this._railObserver.observe(frame);
      frame.__deckThumb = entry;
      return entry;
    }

    /** Lazily build the clone for a thumb that has scrolled into view. */
    _materialize(entry) {
      if (entry.host) return;
      const dw = this.designWidth,
        dh = this.designHeight;
      let clone = entry.slide.cloneNode(true);
      clone.removeAttribute('id');
      clone.removeAttribute('data-deck-active');
      clone.querySelectorAll('[id]').forEach(el => el.removeAttribute('id'));
      // Neuter heavy media; replace <video> with its poster so the box
      // keeps a visual. <iframe>/<audio> become empty placeholders.
      clone.querySelectorAll('iframe, audio, object, embed').forEach(el => {
        el.removeAttribute('src');
        el.removeAttribute('srcdoc');
        el.removeAttribute('data');
        el.innerHTML = '';
      });
      clone.querySelectorAll('video').forEach(el => {
        if (!el.poster) {
          el.removeAttribute('src');
          el.innerHTML = '';
          return;
        }
        const img = document.createElement('img');
        img.src = el.poster;
        img.alt = '';
        img.style.cssText = el.style.cssText + ';object-fit:cover;width:100%;height:100%;';
        img.className = el.className;
        el.replaceWith(img);
      });
      // Images: defer decode and let the browser pick the smallest
      // srcset candidate for the ~140px thumb. Same-URL clones reuse the
      // slide's decoded bitmap (URL-keyed cache), so the remaining cost
      // is paint/composite — lazy+async keeps that off the main thread.
      clone.querySelectorAll('img').forEach(el => {
        el.loading = 'lazy';
        el.decoding = 'async';
        if (el.srcset) el.sizes = (this._railPx || 188) + 'px';
      });
      // Custom elements inside the slide would have their
      // connectedCallback fire when the clone is appended. Replace them
      // with inert boxes so a component-heavy deck doesn't run N copies
      // of each component's mount logic in the rail. Children are
      // preserved so layout-wrapper elements (<my-column><h2>…</h2>)
      // still show their authored content; the querySelectorAll NodeList
      // is static, so nested custom elements in the moved subtree are
      // still visited on later iterations.
      const neuter = el => {
        const box = document.createElement('div');
        box.style.cssText = (el.getAttribute('style') || '') + ';background:rgba(0,0,0,0.06);border:1px dashed rgba(0,0,0,0.15);';
        box.className = el.className;
        // Preserve theming/i18n hooks so [data-*] / :lang() / [dir]
        // descendant selectors still match the neutered root.
        for (const a of el.attributes) {
          const n = a.name;
          if (n.startsWith('data-') || n.startsWith('aria-') || n === 'lang' || n === 'dir' || n === 'role' || n === 'title') {
            box.setAttribute(n, a.value);
          }
        }
        while (el.firstChild) box.appendChild(el.firstChild);
        return box;
      };
      // querySelectorAll('*') returns descendants only — a custom-element
      // slide root (<my-slide>…</my-slide>) would slip through and upgrade
      // on append. Swap the root first.
      if (clone.tagName.includes('-')) clone = neuter(clone);
      clone.querySelectorAll('*').forEach(el => {
        if (el.tagName.includes('-')) el.replaceWith(neuter(el));
      });
      clone.style.cssText += ';position:absolute;top:0;left:0;transform-origin:0 0;' + 'pointer-events:none;width:' + dw + 'px;height:' + dh + 'px;' + 'box-sizing:border-box;overflow:hidden;visibility:visible;opacity:1;';
      const host = document.createElement('div');
      host.style.cssText = 'position:absolute;inset:0;';
      this._syncThumbHostAttrs(host);
      const sr = host.attachShadow({
        mode: 'open'
      });
      if (this._adoptedSheet) sr.adoptedStyleSheets = [this._adoptedSheet];else {
        const st = document.createElement('style');
        st.textContent = this._authorCss || '';
        sr.appendChild(st);
      }
      sr.appendChild(clone);
      entry.frame.appendChild(host);
      entry.host = host;
      entry.clone = clone;
      if (this._thumbScale) clone.style.transform = 'scale(' + this._thumbScale + ')';
      // Once materialized the IO callback is a no-op early-return —
      // unobserve so scroll doesn't keep firing it.
      if (this._railObserver) this._railObserver.unobserve(entry.frame);
    }

    /** Re-clone a single thumb (live-update path). No-op if the thumb
     *  hasn't been materialized yet — it'll pick up current content when
     *  it scrolls into view. */
    _refreshThumb(slide) {
      const entry = (this._thumbs || []).find(t => t.slide === slide);
      if (!entry || !entry.host) return;
      entry.host.remove();
      entry.host = entry.clone = null;
      this._materialize(entry);
    }
    _scaleThumbs() {
      if (!this._thumbs || !this._thumbs.length) return;
      // Every frame is the same width; if it reads 0 the rail is
      // display:none (noscale / no-rail / presenting / print) — leave the
      // clones as-is and re-run when the rail is revealed.
      const fw = this._thumbs[0].frame.offsetWidth;
      if (!fw) return;
      this._thumbScale = fw / this.designWidth;
      this._thumbs.forEach(({
        clone
      }) => {
        if (clone) clone.style.transform = 'scale(' + this._thumbScale + ')';
      });
    }
    _setDrop(i, where) {
      // dragover fires at pointer-event rate; touch only the previous
      // and new target rather than sweeping all N thumbs.
      const t = this._thumbs && this._thumbs[i];
      if (this._dropOn && this._dropOn !== t) {
        this._dropOn.thumb.removeAttribute('data-drop');
      }
      if (t) t.thumb.setAttribute('data-drop', where);
      this._dropOn = t || null;
    }
    _clearDrop() {
      if (this._dropOn) this._dropOn.thumb.removeAttribute('data-drop');
      this._dropOn = null;
    }
    _syncRail(follow) {
      if (!this._thumbs) return;
      this._thumbs.forEach(({
        thumb
      }, i) => {
        if (i === this._index) {
          thumb.setAttribute('data-current', '');
          if (follow && typeof thumb.scrollIntoView === 'function') {
            thumb.scrollIntoView({
              block: 'nearest'
            });
          }
        } else {
          thumb.removeAttribute('data-current');
        }
      });
    }
    _openMenu(i, x, y) {
      if (!this._menu) return;
      this._menuIndex = i;
      const slide = this._slides[i];
      const skip = slide && slide.hasAttribute('data-deck-skip');
      this._menu.querySelector('[data-act="skip"]').textContent = skip ? 'Unskip slide' : 'Skip slide';
      this._menu.querySelector('[data-act="up"]').disabled = i <= 0;
      this._menu.querySelector('[data-act="down"]').disabled = i >= this._slides.length - 1;
      this._menu.querySelector('[data-act="delete"]').disabled = this._slides.length <= 1;
      // Place, then clamp to viewport after it's measurable.
      this._menu.style.left = x + 'px';
      this._menu.style.top = y + 'px';
      this._menu.setAttribute('data-open', '');
      const r = this._menu.getBoundingClientRect();
      const nx = Math.min(x, window.innerWidth - r.width - 4);
      const ny = Math.min(y, window.innerHeight - r.height - 4);
      this._menu.style.left = Math.max(4, nx) + 'px';
      this._menu.style.top = Math.max(4, ny) + 'px';
    }
    _closeMenu() {
      if (this._menu) this._menu.removeAttribute('data-open');
      this._menuIndex = -1;
    }
    _openConfirm(i) {
      if (!this._confirm) return;
      this._confirmIndex = i;
      this._confirm.querySelector('.title').textContent = 'Delete slide ' + (i + 1) + '?';
      this._confirm.setAttribute('data-open', '');
      const btn = this._confirm.querySelector('.danger');
      if (btn && btn.focus) btn.focus();
    }
    _closeConfirm() {
      if (this._confirm) this._confirm.removeAttribute('data-open');
      this._confirmIndex = -1;
    }
    _emitDeckChange(detail) {
      this.dispatchEvent(new CustomEvent('deckchange', {
        detail,
        bubbles: true,
        composed: true
      }));
    }
    _deleteSlide(i) {
      const slide = this._slides[i];
      if (!slide || this._slides.length <= 1) return;
      const wasCurrent = i === this._index;
      if (i < this._index || wasCurrent && i === this._slides.length - 1) this._index--;
      this._squelchSlotChange = true;
      slide.remove();
      this._emitDeckChange({
        action: 'delete',
        from: i,
        slide
      });
      this._collectSlides();
      this._applyIndex({
        showOverlay: true,
        broadcast: true,
        reason: 'mutation'
      });
    }
    _toggleSkip(i) {
      const slide = this._slides[i];
      if (!slide) return;
      const on = !slide.hasAttribute('data-deck-skip');
      if (on) slide.setAttribute('data-deck-skip', '');else slide.removeAttribute('data-deck-skip');
      if (this._thumbs && this._thumbs[i]) {
        if (on) this._thumbs[i].thumb.setAttribute('data-skip', '');else this._thumbs[i].thumb.removeAttribute('data-skip');
      }
      this._markLastVisible();
      this._emitDeckChange({
        action: on ? 'skip' : 'unskip',
        from: i,
        slide
      });
      // Re-broadcast so the presenter popup's prev/next thumbnails re-pick
      // the nearest non-skipped slide without waiting for a nav event.
      try {
        window.postMessage({
          slideIndexChanged: this._index,
          deckTotal: this._slides.length,
          deckSkipped: this._skippedIndices()
        }, '*');
      } catch (e) {}
    }
    _skippedIndices() {
      const out = [];
      for (let i = 0; i < this._slides.length; i++) {
        if (this._slides[i].hasAttribute('data-deck-skip')) out.push(i);
      }
      return out;
    }
    _moveSlide(i, j) {
      if (j < 0 || j >= this._slides.length || j === i) return;
      const slide = this._slides[i];
      const ref = j < i ? this._slides[j] : this._slides[j].nextSibling;
      // Track the active slide across the reorder so the same content
      // stays on screen.
      const cur = this._index;
      if (cur === i) this._index = j;else if (i < cur && j >= cur) this._index = cur - 1;else if (i > cur && j <= cur) this._index = cur + 1;
      this._squelchSlotChange = true;
      this.insertBefore(slide, ref);
      this._emitDeckChange({
        action: 'move',
        from: i,
        to: j,
        slide
      });
      this._collectSlides();
      this._applyIndex({
        showOverlay: false,
        broadcast: true,
        reason: 'mutation'
      });
    }

    // Public API ------------------------------------------------------------

    /** Current slide index (0-based). */
    get index() {
      return this._index;
    }
    /** Total slide count. */
    get length() {
      return this._slides.length;
    }
    /** Programmatically navigate. */
    goTo(i) {
      this._go(i, 'api');
    }
    next() {
      this._advance(1, 'api');
    }
    prev() {
      this._advance(-1, 'api');
    }
    reset() {
      this._go(0, 'api');
    }
  }
  if (!customElements.get('deck-stage')) {
    customElements.define('deck-stage', DeckStage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "deck-stage.js", error: String((e && e.message) || e) }); }

// ui_kits/web/App.jsx
try { (() => {
// AutoTrader UI Kit — App shell + router
const {
  useState: useStateApp
} = React;
function Placeholder({
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '80px 24px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      width: 64,
      height: 64,
      borderRadius: 'var(--radius-xl)',
      background: 'var(--at-blue-100)',
      color: 'var(--at-blue-dark)',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "hammer",
    size: 30
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 28px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '0 0 8px'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      font: '400 16px/1.5 var(--font-ui)',
      color: 'var(--fg-secondary)',
      maxWidth: 460,
      margin: '0 auto'
    }
  }, sub));
}
function SavedScreen({
  onOpen,
  saved,
  onSave
}) {
  const list = window.ATDATA.vehicles.filter(v => saved.includes(v.id));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '32px 24px',
      minHeight: '60vh'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 28px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '0 0 6px'
    }
  }, "Saved cars"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: '400 15px/1 var(--font-ui)',
      color: 'var(--fg-secondary)',
      margin: '0 0 24px'
    }
  }, list.length ? `${list.length} car${list.length > 1 ? 's' : ''} shortlisted` : 'Tap the heart on any car to save it here.'), list.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, list.map(v => /*#__PURE__*/React.createElement(ListingCard, {
    key: v.id,
    v: v,
    saved: true,
    onSave: onSave,
    onOpen: onOpen
  }))));
}
function App() {
  const [view, setView] = useStateApp('home');
  const [vehicle, setVehicle] = useStateApp(null);
  const [saved, setSaved] = useStateApp([2]);
  useLucide(view + (vehicle ? vehicle.id : '') + saved.join(','));
  const onSave = id => setSaved(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const openVehicle = v => {
    setVehicle(v);
    setView('vdp');
    window.scrollTo(0, 0);
  };
  const nav = v => {
    setView(v);
    window.scrollTo(0, 0);
  };
  let screen;
  if (view === 'home') screen = /*#__PURE__*/React.createElement(Home, {
    onNav: nav,
    onOpen: openVehicle,
    saved: saved,
    onSave: onSave
  });else if (view === 'results') screen = /*#__PURE__*/React.createElement(Results, {
    onOpen: openVehicle,
    saved: saved,
    onSave: onSave
  });else if (view === 'vdp' && vehicle) screen = /*#__PURE__*/React.createElement(VDP, {
    v: vehicle,
    onBack: () => nav('results'),
    onFinance: () => nav('finance'),
    saved: saved,
    onSave: onSave
  });else if (view === 'finance') screen = /*#__PURE__*/React.createElement(Finance, {
    onBack: () => vehicle ? nav('vdp') : nav('home')
  });else if (view === 'saved') screen = /*#__PURE__*/React.createElement(SavedScreen, {
    onOpen: openVehicle,
    saved: saved,
    onSave: onSave
  });else if (view === 'sell') screen = /*#__PURE__*/React.createElement(Placeholder, {
    title: "Sell your car",
    sub: "The sell-your-car flow isn't built out in this UI kit. The components above (fields, selects, buttons, photo upload) are the building blocks for it."
  });else if (view === 'dealers') screen = /*#__PURE__*/React.createElement(Placeholder, {
    title: "Find a dealer",
    sub: "The dealer directory isn't built out in this UI kit. Dealer cards and rating components live on the vehicle detail page."
  });else if (view === 'tools') screen = /*#__PURE__*/React.createElement(Placeholder, {
    title: "Tools & Services",
    sub: "Try the Car finance calculator \u2014 open it from a car's price or the homepage promo."
  });else screen = /*#__PURE__*/React.createElement(Home, {
    onNav: nav,
    onOpen: openVehicle,
    saved: saved,
    onSave: onSave
  });
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Header, {
    onNav: nav,
    current: view,
    savedCount: saved.length
  }), screen, /*#__PURE__*/React.createElement(Footer, null));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Cards.jsx
try { (() => {
// AutoTrader UI Kit — ListingCard (shared)
function NoPhoto({
  body
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      background: 'var(--neutral-100)'
    }
  }, /*#__PURE__*/React.createElement(BodyIcon, {
    file: body === 'all' ? 'sedan' : body,
    w: 96,
    color: "var(--neutral-300)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 11px/1 var(--font-ui)',
      color: 'var(--fg-muted)'
    }
  }, "Photos coming soon"));
}
function ListingCard({
  v,
  saved,
  onSave,
  onOpen
}) {
  const F = window.ATFMT;
  return /*#__PURE__*/React.createElement("div", {
    onClick: () => onOpen(v),
    className: "at-card",
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-s)',
      overflow: 'hidden',
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 188,
      background: '#0f1722'
    }
  }, v.photo ? /*#__PURE__*/React.createElement("img", {
    src: v.photo,
    alt: v.title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }) : /*#__PURE__*/React.createElement(NoPhoto, {
    body: v.body
  }), v.tag && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 10,
      top: 10,
      font: '500 11px/1 var(--font-ui)',
      color: '#fff',
      background: v.tag === 'Reduced' ? 'var(--at-red)' : 'var(--success)',
      padding: '5px 8px',
      borderRadius: 'var(--radius-sm)'
    }
  }, v.tag), /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onSave(v.id);
    },
    style: {
      position: 'absolute',
      top: 10,
      right: 10,
      width: 36,
      height: 36,
      borderRadius: '50%',
      background: 'rgba(255,255,255,.94)',
      border: 0,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: saved ? 'var(--at-red)' : 'var(--neutral-600)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "heart",
    size: 19,
    style: {
      fill: saved ? 'var(--at-red)' : 'none'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 16px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 22px/1 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, F.rand(v.price)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 15px/1.3 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, v.title), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 13px/1.4 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, v.year, " \xB7 ", F.km(v.km), " \xB7 ", v.gearbox, " \xB7 ", v.fuel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      paddingTop: 12,
      borderTop: '1px solid var(--border-subtle)',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      font: '400 12px/1 var(--font-ui)',
      color: 'var(--fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 14
  }), " ", v.city, v.verified && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      color: 'var(--success-dark)',
      font: '500 12px/1 var(--font-ui)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 14
  }), " Verified"))));
}
Object.assign(window, {
  ListingCard,
  NoPhoto
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Cards.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Finance.jsx
try { (() => {
// AutoTrader UI Kit — Car finance calculator
const {
  useState: useStateF
} = React;
function Slider({
  label,
  value,
  min,
  max,
  step,
  fmt,
  onChange
}) {
  const pct = (value - min) / (max - min) * 100;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 14px/1 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 16px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)'
    }
  }, fmt(value))), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value)),
    style: {
      width: '100%',
      height: 6,
      borderRadius: 3,
      appearance: 'none',
      cursor: 'pointer',
      background: `linear-gradient(90deg, var(--at-blue) ${pct}%, var(--neutral-200) ${pct}%)`
    }
  }));
}
function Finance({
  onBack
}) {
  const F = window.ATFMT;
  const [price, setPrice] = useStateF(365000);
  const [deposit, setDeposit] = useStateF(36500);
  const [term, setTerm] = useStateF(72);
  const [rate, setRate] = useStateF(11.75);
  const [balloon, setBalloon] = useStateF(10);
  const principal = price - deposit - price * balloon / 100;
  const r = rate / 100 / 12;
  const balloonAmt = price * balloon / 100;
  const monthlyBase = principal * (r * Math.pow(1 + r, term)) / (Math.pow(1 + r, term) - 1);
  const balloonMonthly = balloonAmt * r;
  const monthly = Math.round(monthlyBase + balloonMonthly);
  const totalRepay = Math.round(monthly * term + deposit + balloonAmt);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--neutral-50)',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      padding: '20px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      cursor: 'pointer',
      font: '500 14px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  }), " Back")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 980,
      margin: '0 auto',
      padding: '12px 24px 48px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 32px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '8px 0 4px'
    }
  }, "Car finance calculator"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: '400 16px/1.4 var(--font-ui)',
      color: 'var(--fg-secondary)',
      margin: '0 0 28px'
    }
  }, "Estimate your monthly repayment. Figures are indicative only."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 340px',
      gap: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: 28,
      display: 'flex',
      flexDirection: 'column',
      gap: 26
    }
  }, /*#__PURE__*/React.createElement(Slider, {
    label: "Vehicle price",
    value: price,
    min: 50000,
    max: 1500000,
    step: 5000,
    fmt: F.rand,
    onChange: setPrice
  }), /*#__PURE__*/React.createElement(Slider, {
    label: "Deposit",
    value: deposit,
    min: 0,
    max: price * 0.5,
    step: 1000,
    fmt: n => F.rand(n) + ` · ${Math.round(n / price * 100)}%`,
    onChange: setDeposit
  }), /*#__PURE__*/React.createElement(Slider, {
    label: "Repayment term",
    value: term,
    min: 12,
    max: 84,
    step: 6,
    fmt: n => n + ' months',
    onChange: setTerm
  }), /*#__PURE__*/React.createElement(Slider, {
    label: "Interest rate (per annum)",
    value: rate,
    min: 7,
    max: 20,
    step: 0.25,
    fmt: n => n.toFixed(2) + '%',
    onChange: setRate
  }), /*#__PURE__*/React.createElement(Slider, {
    label: "Balloon payment",
    value: balloon,
    min: 0,
    max: 40,
    step: 5,
    fmt: n => n + '%',
    onChange: setBalloon
  })), /*#__PURE__*/React.createElement("aside", {
    style: {
      position: 'sticky',
      top: 88,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--at-blue)',
      color: '#fff',
      borderRadius: 'var(--radius-xl)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 14px/1 var(--font-ui)',
      color: 'rgba(255,255,255,.85)'
    }
  }, "Estimated monthly repayment"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: '500 40px/1.05 var(--font-ui)',
      margin: '8px 0 2px'
    }
  }, F.rand(monthly)), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 13px/1 var(--font-ui)',
      color: 'rgba(255,255,255,.8)'
    }
  }, "over ", term, " months")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, [['Vehicle price', F.rand(price)], ['Deposit', F.rand(deposit)], ['Balloon payment', F.rand(Math.round(balloonAmt))], ['Total repayment', F.rand(totalRepay)]].map(([k, val]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--fg-primary)',
      fontWeight: 500
    }
  }, val))), /*#__PURE__*/React.createElement(Btn, {
    variant: "solid",
    size: "lg",
    full: true,
    style: {
      marginTop: 6
    }
  }, "Apply for finance"))))));
}
Object.assign(window, {
  Finance
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Finance.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Header.jsx
try { (() => {
// AutoTrader UI Kit — Header + Footer
const {
  useState: useStateH
} = React;
function Header({
  onNav,
  current,
  savedCount
}) {
  const links = [{
    id: 'home',
    label: 'Buy a car'
  }, {
    id: 'sell',
    label: 'Sell your car'
  }, {
    id: 'finance',
    label: 'Car finance'
  }, {
    id: 'dealers',
    label: 'Dealers'
  }, {
    id: 'tools',
    label: 'Tools & Services'
  }];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 50,
      background: '#fff',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      height: 72,
      padding: '0 24px',
      display: 'flex',
      alignItems: 'center',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('home'),
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 26
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 22,
      marginLeft: 8
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.id,
    onClick: () => onNav(l.id === 'home' ? 'results' : l.id),
    style: {
      font: '700 15px/1 var(--font-label)',
      letterSpacing: '-0.005em',
      cursor: 'pointer',
      color: current === l.id || l.id === 'home' && current === 'results' ? 'var(--at-blue-dark)' : 'var(--fg-primary)'
    }
  }, l.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('saved'),
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--fg-secondary)',
      font: '500 14px/1 var(--font-ui)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "heart",
    size: 22
  }), savedCount > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: -6,
      right: -8,
      minWidth: 16,
      height: 16,
      borderRadius: 8,
      background: 'var(--at-red)',
      color: '#fff',
      font: '700 10px/16px var(--font-label)',
      textAlign: 'center',
      padding: '0 3px'
    }
  }, savedCount)), "Saved"), /*#__PURE__*/React.createElement("a", {
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--fg-secondary)',
      font: '500 14px/1 var(--font-ui)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user",
    size: 22
  }), " Sign in"), /*#__PURE__*/React.createElement(Btn, {
    variant: "red",
    size: "md",
    onClick: () => onNav('sell')
  }, "Sell your car"))));
}
function Footer() {
  const cols = [['Buy', ['Search used cars', 'New car deals', 'Find a dealer', 'Car reviews']], ['Sell', ['Sell your car', 'Get a valuation', 'Trade-in', 'Dealer enquiries']], ['Tools & Services', ['Car finance calculator', 'Car finance', 'Insurance', 'Vehicle history check']], ['AutoTrader', ['About us', 'Careers', 'Contact', 'Help centre']]];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--neutral-950)',
      color: '#fff',
      marginTop: 64
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '48px 24px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 48,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 260px',
      minWidth: 240
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 26,
    light: true,
    withStrap: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 20
    }
  }, ['facebook', 'instagram', 'youtube', 'twitter'].map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      background: 'rgba(255,255,255,.1)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'rgba(255,255,255,.8)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '700 13px/1 var(--font-label)',
      textTransform: 'capitalize'
    }
  }, s[0]))))), cols.map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 14px/1 var(--font-ui)',
      color: '#fff'
    }
  }, h), items.map(it => /*#__PURE__*/React.createElement("a", {
    key: it,
    style: {
      font: '400 14px/1 var(--font-ui)',
      color: 'rgba(255,255,255,.7)',
      cursor: 'pointer'
    }
  }, it))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40,
      paddingTop: 20,
      borderTop: '1px solid rgba(255,255,255,.12)',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 12,
      font: '400 12px/1.5 var(--font-ui)',
      color: 'rgba(255,255,255,.5)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 AutoTrader South Africa. The trusted motoring marketplace."), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("a", {
    style: {
      color: 'inherit',
      cursor: 'pointer'
    }
  }, "Terms & Conditions"), /*#__PURE__*/React.createElement("a", {
    style: {
      color: 'inherit',
      cursor: 'pointer'
    }
  }, "Privacy Policy")))));
}
Object.assign(window, {
  Header,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Home.jsx
try { (() => {
// AutoTrader UI Kit — Home screen
const {
  useState: useStateHome
} = React;
function HeroSearch({
  onSearch
}) {
  const D = window.ATDATA;
  const [make, setMake] = useStateHome('Any make');
  const [body, setBody] = useStateHome('all');
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      background: 'var(--neutral-950)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/photos/car-a.jpg",
    alt: "",
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      opacity: 0.34
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, rgba(2,6,23,.92) 0%, rgba(2,6,23,.72) 55%, rgba(2,6,23,.45) 100%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 1280,
      margin: '0 auto',
      padding: '64px 24px 56px'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 48px/1.05 var(--font-ui)',
      color: '#fff',
      margin: 0,
      maxWidth: 620
    }
  }, "Find your next car"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: '400 18px/1.4 var(--font-ui)',
      color: 'rgba(255,255,255,.82)',
      margin: '14px 0 0',
      maxWidth: 540
    }
  }, "Search thousands of quality used cars from trusted dealers across South Africa."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 32,
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      maxWidth: 920
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Make",
    value: make,
    onChange: setMake,
    options: D.makes
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Model",
    value: "Any model",
    onChange: () => {},
    options: ['Any model', 'Urban Cruiser', 'Magnite', 'Polo', 'Ranger']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Min price",
    value: "No min",
    onChange: () => {},
    options: ['No min', 'R 100 000', 'R 200 000', 'R 300 000']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Max price",
    value: "No max",
    onChange: () => {},
    options: ['No max', 'R 300 000', 'R 500 000', 'R 1 000 000']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 12px/1 var(--font-ui)',
      color: 'var(--fg-secondary)',
      marginRight: 2
    }
  }, "Body type"), D.bodyStyles.slice(1, 7).map(b => /*#__PURE__*/React.createElement(Chip, {
    key: b.id,
    active: body === b.id,
    onClick: () => setBody(b.id)
  }, b.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: onSearch,
    style: {
      font: '500 14px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)',
      cursor: 'pointer'
    }
  }, "More filters"), /*#__PURE__*/React.createElement(Btn, {
    variant: "solid",
    size: "lg",
    icon: "search",
    onClick: onSearch
  }, "Search 8,412 cars")))));
}
function BrowseByBody({
  onPick
}) {
  const D = window.ATDATA;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '48px 24px 8px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: '500 28px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '0 0 20px'
    }
  }, "Browse by body type"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: 14
    }
  }, D.bodyStyles.slice(1).map(b => /*#__PURE__*/React.createElement("button", {
    key: b.id,
    onClick: onPick,
    className: "at-bodytile",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      padding: '20px 8px',
      borderRadius: 'var(--radius-lg)',
      cursor: 'pointer',
      border: '1px solid var(--border-subtle)',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement(BodyIcon, {
    file: b.file,
    w: 64,
    color: "var(--neutral-600)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 13px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, b.label)))));
}
function Promos({
  onFinance
}) {
  const items = [{
    icon: 'shield-check',
    t: 'Buy with confidence',
    d: 'Every dealer is rated and reviewed by real buyers.'
  }, {
    icon: 'calculator',
    t: 'Car finance made simple',
    d: 'Estimate your monthly repayment in seconds.',
    cta: 'Open calculator'
  }, {
    icon: 'tag',
    t: 'Sell your car for free',
    d: 'List in minutes and reach thousands of buyers.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '40px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    }
  }, items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: '#fff',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-md)',
      background: 'var(--at-blue-100)',
      color: 'var(--at-blue-dark)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: it.icon,
    size: 24
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 18px/1.2 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, it.t), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1.5 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, it.d), it.cta && /*#__PURE__*/React.createElement("a", {
    onClick: onFinance,
    style: {
      marginTop: 4,
      font: '700 14px/1 var(--font-label)',
      color: 'var(--at-blue-dark)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, it.cta, " ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 16
  }))))));
}
function Home({
  onNav,
  onOpen,
  saved,
  onSave
}) {
  const D = window.ATDATA;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(HeroSearch, {
    onSearch: () => onNav('results')
  }), /*#__PURE__*/React.createElement(BrowseByBody, {
    onPick: () => onNav('results')
  }), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '40px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: '500 28px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: 0
    }
  }, "Featured cars"), /*#__PURE__*/React.createElement("a", {
    onClick: () => onNav('results'),
    style: {
      font: '700 14px/1 var(--font-label)',
      color: 'var(--at-blue-dark)',
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, "View all ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 16
    }
  }, D.vehicles.slice(0, 4).map(v => /*#__PURE__*/React.createElement(ListingCard, {
    key: v.id,
    v: v,
    saved: saved.includes(v.id),
    onSave: onSave,
    onOpen: onOpen
  })))), /*#__PURE__*/React.createElement(Promos, {
    onFinance: () => onNav('finance')
  }));
}
Object.assign(window, {
  Home
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Home.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Primitives.jsx
try { (() => {
// AutoTrader UI Kit — shared primitives. Exposes components on window.
const {
  useState,
  useEffect,
  useRef,
  useCallback
} = React;

// ---- Icons (Lucide UMD). <Icon name="search" .../> renders an <i> that the
// global lucide.createIcons() upgrades to an SVG. useLucide() re-runs it. ----
function Icon({
  name,
  size = 20,
  color,
  strokeWidth = 2,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    className: className,
    style: {
      display: 'inline-flex',
      width: size,
      height: size,
      color,
      ['--lucide-sw']: strokeWidth,
      ...style
    }
  });
}
function useLucide(dep) {
  useEffect(() => {
    if (window.lucide) {
      lucide.createIcons({
        attrs: {
          'stroke-width': 2,
          width: 24,
          height: 24
        }
      });
    }
  });
}

// ---- Brand logo (wordmark img; recolours white on dark via filter) ----
function Logo({
  height = 26,
  light = false,
  withStrap = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: light ? '../../assets/logo-wordmark.svg' : '../../assets/logo-wordmark-colour.svg',
    alt: "AutoTrader",
    style: {
      height,
      width: 'auto',
      filter: light ? 'brightness(0) invert(1)' : 'none'
    }
  }), withStrap && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'italic 500 11px/1 var(--font-ui)',
      color: light ? 'rgba(255,255,255,.85)' : 'var(--at-blue-dark)'
    }
  }, "The trusted motoring marketplace"));
}

// ---- Button ----
function Btn({
  children,
  variant = 'solid',
  size = 'md',
  icon,
  iconRight,
  full,
  onClick,
  type,
  style
}) {
  const sizes = {
    lg: {
      h: 48,
      px: 24,
      fs: 16
    },
    md: {
      h: 40,
      px: 18,
      fs: 14
    },
    sm: {
      h: 32,
      px: 14,
      fs: 12
    }
  };
  const s = sizes[size];
  const variants = {
    solid: {
      background: 'var(--at-blue)',
      color: '#fff',
      border: '1px solid transparent'
    },
    red: {
      background: 'var(--at-red)',
      color: '#fff',
      border: '1px solid transparent'
    },
    outline: {
      background: '#fff',
      color: 'var(--at-blue-dark)',
      border: '1px solid var(--neutral-300)'
    },
    text: {
      background: 'transparent',
      color: 'var(--at-blue-dark)',
      border: '1px solid transparent'
    },
    ghost: {
      background: 'var(--neutral-100)',
      color: 'var(--fg-primary)',
      border: '1px solid transparent'
    }
  };
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    onClick: onClick,
    className: 'at-btn at-btn-' + variant,
    style: {
      height: s.h,
      padding: `0 ${s.px}px`,
      font: `700 ${s.fs}px/1 var(--font-label)`,
      borderRadius: 'var(--radius-md)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 8,
      cursor: 'pointer',
      width: full ? '100%' : 'auto',
      whiteSpace: 'nowrap',
      ...variants[variant],
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: s.fs + 2
  }), children, iconRight && /*#__PURE__*/React.createElement(Icon, {
    name: iconRight,
    size: s.fs + 2
  }));
}

// ---- Badge / Chip ----
function Badge({
  children,
  tone = 'neutral',
  dot
}) {
  const tones = {
    success: ['var(--success-light)', 'var(--success-dark)', 'var(--success)'],
    info: ['var(--at-blue-100)', 'var(--at-blue-dark)', 'var(--at-blue)'],
    warning: ['var(--warning-light)', 'var(--warning-dark)', 'var(--warning-dark)'],
    error: ['var(--error-light)', 'var(--error-dark)', 'var(--error)'],
    neutral: ['var(--neutral-100)', 'var(--fg-secondary)', 'var(--neutral-400)']
  };
  const [bg, fg, d] = tones[tone];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 12px/1 var(--font-ui)',
      padding: '5px 10px',
      borderRadius: 'var(--radius-pill)',
      background: bg,
      color: fg,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: d
    }
  }), children);
}
function Chip({
  children,
  active,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      font: '500 13px/1 var(--font-ui)',
      padding: '8px 14px',
      borderRadius: 'var(--radius-pill)',
      cursor: 'pointer',
      border: '1px solid ' + (active ? 'var(--at-blue)' : 'var(--neutral-300)'),
      color: active ? 'var(--at-blue-dark)' : 'var(--fg-secondary)',
      background: active ? 'var(--at-blue-50)' : '#fff'
    }
  }, children);
}

// ---- Star rating ----
function Stars({
  value,
  size = 14
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 1,
      color: 'var(--warning-dark)'
    }
  }, [1, 2, 3, 4, 5].map(i => /*#__PURE__*/React.createElement(Icon, {
    key: i,
    name: "star",
    size: size,
    style: {
      fill: i <= Math.round(value) ? 'var(--warning-dark)' : 'none'
    }
  })));
}

// ---- Body-style silhouette (fetches svg, recolours via currentColor) ----
const _bodyCache = {};
function BodyIcon({
  file,
  w = 56,
  color = 'var(--neutral-400)'
}) {
  const ref = useRef(null);
  useEffect(() => {
    const url = '../../assets/body-styles/' + file + '.svg';
    const apply = txt => {
      if (ref.current) ref.current.innerHTML = txt;
    };
    if (_bodyCache[file]) apply(_bodyCache[file]);else fetch(url).then(r => r.text()).then(t => {
      _bodyCache[file] = t;
      apply(t);
    });
  }, [file]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      width: w,
      color,
      alignItems: 'center',
      justifyContent: 'center'
    }
  });
}

// ---- Text field ----
function Field({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  prefix,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 12px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      height: 42,
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border-default)',
      background: '#fff',
      padding: '0 12px',
      gap: 6
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-muted)'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: e => onChange && onChange(e.target.value),
    placeholder: placeholder,
    type: type,
    style: {
      border: 0,
      outline: 'none',
      flex: 1,
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-primary)',
      background: 'transparent',
      minWidth: 0
    }
  })));
}

// ---- Select (native, styled) ----
function Select({
  label,
  value,
  onChange,
  options,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 12px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: value,
    onChange: e => onChange && onChange(e.target.value),
    style: {
      width: '100%',
      height: 42,
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border-default)',
      background: '#fff',
      padding: '0 36px 0 12px',
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-primary)',
      appearance: 'none',
      cursor: 'pointer'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--fg-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 18
  }))));
}
Object.assign(window, {
  Icon,
  useLucide,
  Logo,
  Btn,
  Badge,
  Chip,
  Stars,
  BodyIcon,
  Field,
  Select
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Primitives.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/Results.jsx
try { (() => {
// AutoTrader UI Kit — Search Results
const {
  useState: useStateR
} = React;
function FilterGroup({
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '18px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: '500 14px/1 var(--font-ui)',
      color: 'var(--fg-primary)',
      marginBottom: 14
    }
  }, title), children);
}
function Check({
  label,
  count,
  checked,
  onToggle
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '5px 0',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 4,
      flex: 'none',
      border: '1px solid ' + (checked ? 'var(--at-blue)' : 'var(--neutral-300)'),
      background: checked ? 'var(--at-blue)' : '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, checked && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 13,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-secondary)',
      flex: 1
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 12px/1 var(--font-ui)',
      color: 'var(--fg-muted)'
    }
  }, count));
}
function Results({
  onOpen,
  saved,
  onSave
}) {
  const D = window.ATDATA;
  const [body, setBody] = useStateR('all');
  const [fuel, setFuel] = useStateR({
    Petrol: true,
    Diesel: false
  });
  const [sort, setSort] = useStateR('Most relevant');
  let list = D.vehicles.filter(v => body === 'all' ? true : v.body === body);
  if (sort === 'Price: low to high') list = [...list].sort((a, b) => a.price - b.price);
  if (sort === 'Price: high to low') list = [...list].sort((a, b) => b.price - a.price);
  if (sort === 'Newest') list = [...list].sort((a, b) => b.year - a.year);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--neutral-50)',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderBottom: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '16px 24px',
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      height: 48,
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--neutral-300)',
      padding: '0 14px',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 20,
    color: "var(--fg-muted)"
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "Search Make, Model or Variant",
    style: {
      border: 0,
      outline: 'none',
      flex: 1,
      font: '400 16px/1 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  })), /*#__PURE__*/React.createElement(Btn, {
    variant: "outline",
    size: "lg",
    icon: "map-pin"
  }, "Cape Town \xB7 50km"), /*#__PURE__*/React.createElement(Btn, {
    variant: "solid",
    size: "lg"
  }, "Search"))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '24px',
      display: 'grid',
      gridTemplateColumns: '280px 1fr',
      gap: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: '4px 20px 12px',
      position: 'sticky',
      top: 88
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 0 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 16px/1 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, "Filters"), /*#__PURE__*/React.createElement("a", {
    style: {
      font: '500 13px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)',
      cursor: 'pointer'
    }
  }, "Clear all")), /*#__PURE__*/React.createElement(FilterGroup, {
    title: "Body type"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, D.bodyStyles.slice(1, 7).map(b => /*#__PURE__*/React.createElement("button", {
    key: b.id,
    onClick: () => setBody(b.id),
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6,
      padding: '10px 4px',
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      border: '1px solid ' + (body === b.id ? 'var(--at-blue)' : 'var(--border-subtle)'),
      background: body === b.id ? 'var(--at-blue-50)' : '#fff'
    }
  }, /*#__PURE__*/React.createElement(BodyIcon, {
    file: b.file,
    w: 48,
    color: body === b.id ? 'var(--at-blue)' : 'var(--neutral-500)'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 12px/1 var(--font-ui)',
      color: body === b.id ? 'var(--at-blue-dark)' : 'var(--fg-secondary)'
    }
  }, b.label))))), /*#__PURE__*/React.createElement(FilterGroup, {
    title: "Price range"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Field, {
    placeholder: "Min",
    prefix: "R"
  }), /*#__PURE__*/React.createElement(Field, {
    placeholder: "Max",
    prefix: "R"
  }))), /*#__PURE__*/React.createElement(FilterGroup, {
    title: "Fuel type"
  }, ['Petrol', 'Diesel', 'Hybrid', 'Electric'].map(f => /*#__PURE__*/React.createElement(Check, {
    key: f,
    label: f,
    count: f === 'Petrol' ? 6112 : f === 'Diesel' ? 1840 : f === 'Hybrid' ? 312 : 148,
    checked: !!fuel[f],
    onToggle: () => setFuel({
      ...fuel,
      [f]: !fuel[f]
    })
  }))), /*#__PURE__*/React.createElement(FilterGroup, {
    title: "Transmission"
  }, ['Automatic', 'Manual'].map(t => /*#__PURE__*/React.createElement(Check, {
    key: t,
    label: t,
    count: t === 'Automatic' ? 5210 : 3202,
    checked: false
  })))), /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16,
      flexWrap: 'wrap',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 24px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: 0
    }
  }, "Used cars for sale"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 14px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, list.length, " of 8,412 results")), /*#__PURE__*/React.createElement(Select, {
    value: sort,
    onChange: setSort,
    options: ['Most relevant', 'Price: low to high', 'Price: high to low', 'Newest'],
    style: {
      width: 220
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "info",
    dot: true
  }, "Petrol"), body !== 'all' && /*#__PURE__*/React.createElement(Badge, {
    tone: "info",
    dot: true
  }, D.bodyStyles.find(b => b.id === body).label), /*#__PURE__*/React.createElement("a", {
    style: {
      font: '500 13px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)',
      cursor: 'pointer',
      alignSelf: 'center'
    }
  }, "Save this search")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    }
  }, list.map(v => /*#__PURE__*/React.createElement(ListingCard, {
    key: v.id,
    v: v,
    saved: saved.includes(v.id),
    onSave: onSave,
    onOpen: onOpen
  }))))));
}
Object.assign(window, {
  Results
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/Results.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/VDP.jsx
try { (() => {
// AutoTrader UI Kit — Vehicle Detail Page (VDP)
const {
  useState: useStateV
} = React;
function SpecItem({
  icon,
  label,
  value
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-md)',
      background: 'var(--neutral-100)',
      color: 'var(--fg-secondary)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 12px/1.3 var(--font-ui)',
      color: 'var(--fg-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 15px/1.3 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, value)));
}
function VDP({
  v,
  onBack,
  onFinance,
  saved,
  onSave
}) {
  const F = window.ATFMT;
  const monthly = Math.round(v.price * 1.11 / 72);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--neutral-50)',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '20px 24px 0'
    }
  }, /*#__PURE__*/React.createElement("a", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      cursor: 'pointer',
      font: '500 14px/1 var(--font-ui)',
      color: 'var(--at-blue-dark)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  }), " Back to results")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1280,
      margin: '0 auto',
      padding: '16px 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 360px',
      gap: 24,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("main", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: 'var(--radius-xl)',
      overflow: 'hidden',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 420,
      background: '#0f1722'
    }
  }, v.photo ? /*#__PURE__*/React.createElement("img", {
    src: v.photo,
    alt: v.title,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : /*#__PURE__*/React.createElement(NoPhoto, {
    body: v.body
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 14,
      bottom: 14,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      font: '500 13px/1 var(--font-ui)',
      color: '#fff',
      background: 'rgba(2,6,23,.65)',
      padding: '8px 12px',
      borderRadius: 'var(--radius-pill)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "camera",
    size: 16
  }), " 1 / 24"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 14,
      bottom: 14,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      font: '500 13px/1 var(--font-ui)',
      color: 'var(--fg-primary)',
      background: 'rgba(255,255,255,.92)',
      padding: '8px 12px',
      borderRadius: 'var(--radius-pill)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "rotate-3d",
    size: 16
  }), " 360\xB0 view")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      padding: 10,
      background: '#fff'
    }
  }, [v.photo, null, v.photo, null].map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 88,
      height: 60,
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      border: i === 0 ? '2px solid var(--at-blue)' : '1px solid var(--border-subtle)',
      background: 'var(--neutral-100)'
    }
  }, p ? /*#__PURE__*/React.createElement("img", {
    src: p,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(BodyIcon, {
    file: v.body === 'all' ? 'sedan' : v.body,
    w: 56,
    color: "var(--neutral-300)"
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: '8px 24px 16px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: '500 20px/1.2 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '16px 0 4px'
    }
  }, "Vehicle details"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '0 24px'
    }
  }, /*#__PURE__*/React.createElement(SpecItem, {
    icon: "calendar",
    label: "Year",
    value: v.year
  }), /*#__PURE__*/React.createElement(SpecItem, {
    icon: "gauge",
    label: "Mileage",
    value: F.km(v.km)
  }), /*#__PURE__*/React.createElement(SpecItem, {
    icon: "settings-2",
    label: "Transmission",
    value: v.gearbox
  }), /*#__PURE__*/React.createElement(SpecItem, {
    icon: "fuel",
    label: "Fuel type",
    value: v.fuel
  }), /*#__PURE__*/React.createElement(SpecItem, {
    icon: "car-front",
    label: "Body type",
    value: D_bodyLabel(v.body)
  }), /*#__PURE__*/React.createElement(SpecItem, {
    icon: "palette",
    label: "Colour",
    value: "White"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: '20px 24px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      font: '500 20px/1.2 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '0 0 10px'
    }
  }, "Description"), /*#__PURE__*/React.createElement("p", {
    style: {
      font: '400 15px/1.6 var(--font-ui)',
      color: 'var(--fg-secondary)',
      margin: 0
    }
  }, "Immaculate ", v.year, " ", v.make, " ", v.model, " ", v.variant, " with full service history and a balance of manufacturer warranty. ", v.gearbox, " transmission, ", v.fuel.toLowerCase(), " engine and only ", F.km(v.km), " on the clock. Finance and trade-ins welcome \u2014 contact the dealer to arrange a test drive."))), /*#__PURE__*/React.createElement("aside", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      position: 'sticky',
      top: 88
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      boxShadow: 'var(--shadow-s)',
      padding: 20,
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, v.tag && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: v.tag === 'Reduced' ? 'error' : 'success',
    dot: true
  }, v.tag)), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: '500 22px/1.25 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: 0
    }
  }, v.title), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 32px/1.1 var(--font-ui)',
      color: 'var(--fg-primary)',
      margin: '8px 0 2px'
    }
  }, F.rand(v.price)), /*#__PURE__*/React.createElement("a", {
    onClick: onFinance,
    style: {
      font: '400 14px/1.4 var(--font-ui)',
      color: 'var(--fg-secondary)',
      cursor: 'pointer'
    }
  }, "or approx. ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--at-blue-dark)'
    }
  }, F.rand(monthly)), " p/m \xB7 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--at-blue-dark)',
      textDecoration: 'underline'
    }
  }, "Calculate finance")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Btn, {
    variant: "solid",
    size: "lg",
    full: true,
    icon: "message-square"
  }, "Enquire now"), /*#__PURE__*/React.createElement(Btn, {
    variant: "outline",
    size: "lg",
    full: true,
    icon: "phone"
  }, "Show number"), /*#__PURE__*/React.createElement(Btn, {
    variant: "text",
    size: "md",
    full: true,
    icon: saved.includes(v.id) ? 'heart' : 'heart',
    onClick: () => onSave(v.id)
  }, saved.includes(v.id) ? 'Saved' : 'Save this car'))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 'var(--radius-xl)',
      border: '1px solid var(--border-subtle)',
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 48,
      height: 48,
      borderRadius: 'var(--radius-md)',
      background: 'var(--at-blue-100)',
      color: 'var(--at-blue-dark)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      font: '700 18px/1 var(--font-label)'
    }
  }, v.dealer[0]), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: '500 15px/1.2 var(--font-ui)',
      color: 'var(--fg-primary)'
    }
  }, v.dealer), v.verified && /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 16,
    color: "var(--success-dark)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 3
    }
  }, /*#__PURE__*/React.createElement(Stars, {
    value: v.rating
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      font: '400 12px/1 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, v.rating, " (", v.reviews, ")")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 14,
      font: '400 13px/1.4 var(--font-ui)',
      color: 'var(--fg-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "map-pin",
    size: 15
  }), " ", v.city, ", South Africa"), /*#__PURE__*/React.createElement(Btn, {
    variant: "outline",
    size: "md",
    full: true,
    style: {
      marginTop: 14
    }
  }, "View all stock")))));
}
function D_bodyLabel(id) {
  const b = window.ATDATA.bodyStyles.find(x => x.id === id);
  return b ? b.label : id;
}
Object.assign(window, {
  VDP
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/VDP.jsx", error: String((e && e.message) || e) }); }

// ui_kits/web/data.js
try { (() => {
// AutoTrader UI Kit — sample marketplace data (window.ATDATA)
// Photos pulled from the Figma file; "no photo" listings use the silhouette
// placeholder pattern (AutoTrader ships a No-Image set for exactly this).
window.ATDATA = {
  bodyStyles: [{
    id: 'all',
    label: 'All',
    file: 'suv'
  }, {
    id: 'hatchback',
    label: 'Hatchback',
    file: 'hatchback'
  }, {
    id: 'sedan',
    label: 'Sedan',
    file: 'sedan'
  }, {
    id: 'suv',
    label: 'SUV',
    file: 'suv'
  }, {
    id: 'coupe',
    label: 'Coupé',
    file: 'coupe'
  }, {
    id: 'wagon',
    label: 'Wagon',
    file: 'wagon'
  }, {
    id: 'mpv',
    label: 'MPV',
    file: 'mpv'
  }, {
    id: 'bakkie',
    label: 'Bakkie',
    file: 'bakkie'
  }],
  vehicles: [{
    id: 1,
    make: 'Toyota',
    model: 'Urban Cruiser',
    variant: '1.5 Xs',
    title: 'Toyota Urban Cruiser 1.5 Xs',
    price: 365000,
    year: 2024,
    km: 8500,
    gearbox: 'Manual',
    fuel: 'Petrol',
    body: 'suv',
    city: 'Johannesburg',
    photo: '../../assets/photos/car-b.jpg',
    tag: 'Great price',
    dealer: 'Mega Motors',
    verified: true,
    rating: 4.8,
    reviews: 212
  }, {
    id: 2,
    make: 'Nissan',
    model: 'Magnite',
    variant: '1.0T Acenta CVT',
    title: 'Nissan Magnite 1.0T Acenta CVT',
    price: 312900,
    year: 2023,
    km: 21400,
    gearbox: 'Automatic',
    fuel: 'Petrol',
    body: 'suv',
    city: 'Cape Town',
    photo: '../../assets/photos/car-c.jpg',
    tag: null,
    dealer: 'The King Car Dealer',
    verified: true,
    rating: 4.9,
    reviews: 487
  }, {
    id: 3,
    make: 'Volkswagen',
    model: 'Polo',
    variant: '1.0 TSI Life',
    title: 'Volkswagen Polo 1.0 TSI Life',
    price: 289900,
    year: 2022,
    km: 34100,
    gearbox: 'Manual',
    fuel: 'Petrol',
    body: 'hatchback',
    city: 'Pretoria',
    photo: null,
    tag: null,
    dealer: 'City Auto',
    verified: false,
    rating: 4.3,
    reviews: 64
  }, {
    id: 4,
    make: 'Ford',
    model: 'Ranger',
    variant: '2.0 BiT XLT 4x4',
    title: 'Ford Ranger 2.0 BiT XLT 4x4',
    price: 689900,
    year: 2023,
    km: 41000,
    gearbox: 'Automatic',
    fuel: 'Diesel',
    body: 'bakkie',
    city: 'Durban',
    photo: null,
    tag: 'Reduced',
    dealer: 'Coastal 4x4',
    verified: true,
    rating: 4.7,
    reviews: 158
  }, {
    id: 5,
    make: 'Toyota',
    model: 'Urban Cruiser',
    variant: '1.5 Xr',
    title: 'Toyota Urban Cruiser 1.5 Xr',
    price: 389000,
    year: 2024,
    km: 3200,
    gearbox: 'Automatic',
    fuel: 'Petrol',
    body: 'suv',
    city: 'Sandton',
    photo: '../../assets/photos/car-b.jpg',
    tag: 'Low mileage',
    dealer: 'Mega Motors',
    verified: true,
    rating: 4.8,
    reviews: 212
  }, {
    id: 6,
    make: 'Nissan',
    model: 'Magnite',
    variant: '1.0 Visia',
    title: 'Nissan Magnite 1.0 Visia',
    price: 264900,
    year: 2022,
    km: 52800,
    gearbox: 'Manual',
    fuel: 'Petrol',
    body: 'suv',
    city: 'Bloemfontein',
    photo: '../../assets/photos/car-c.jpg',
    tag: null,
    dealer: 'Value Cars',
    verified: false,
    rating: 4.1,
    reviews: 38
  }],
  makes: ['Any make', 'Toyota', 'Volkswagen', 'Nissan', 'Ford', 'Hyundai', 'Suzuki', 'BMW', 'Mercedes-Benz']
};
window.ATFMT = {
  rand: n => 'R\u00A0' + n.toLocaleString('en-ZA').replace(/,/g, '\u00A0'),
  km: n => n.toLocaleString('en-ZA').replace(/,/g, '\u00A0') + '\u00A0km'
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/web/data.js", error: String((e && e.message) || e) }); }

})();
